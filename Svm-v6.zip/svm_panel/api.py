# Source Generated with Decompyle++
# File: api.pyc (Python 3.12)

'''
Svm Panel - Comprehensive REST API
Full management API for Svm Panel
'''
from flask import Blueprint, request, jsonify
from functools import wraps
import secrets
import hashlib
from datetime import datetime
import logging
api_bp = Blueprint('api', __name__, url_prefix = '/api/v1')
logger = logging.getLogger(__name__)

def require_api_key(f):
    '''Decorator to require API key authentication'''
    decorated_function = (lambda : get_db = get_dbimport hvmif not request.headers.get('X-API-Key'):
request.headers.get('X-API-Key')api_key = request.args.get('api_key')if not api_key:
(jsonify({
'success': False,
'error': 'API key required',
'message': 'Provide API key in X-API-Key header or api_key parameter' }), 401)try:
passexcept Exception:
e = Nonelogger.error(f'''API key validation error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT u.*, ak.* FROM api_keys ak\n                              JOIN users u ON ak.user_id = u.id\n                              WHERE ak.key = ? AND ak.is_active = 1', (api_key,))result = cur.fetchone()if not result:
None(None, None)with None:
if not :
passNone.execute('UPDATE api_keys SET last_used_at = ? WHERE key = ?', (datetime.now().isoformat(), api_key))conn.commit(){
'key_id': result['id'],
'user_id': result['user_id'],
'is_admin': result['is_admin'] } = dict(result)None(None, None)args({ }, kwargs = None)try:
conn = Nonecur = conn.cursor()cur.execute('SELECT u.*, ak.* FROM api_keys ak\n                              JOIN users u ON ak.user_id = u.id\n                              WHERE ak.key = ? AND ak.is_active = 1', (api_key,))result = cur.fetchone()if not result:
None(None, None)with None:
if not :
passexcept:
passcontinue)()
    return decorated_function


def require_admin_api(f):
    '''Decorator to require admin API key'''
    decorated_function = (lambda : if not request.api_key_info.get('is_admin'):
(jsonify({
'success': False,
'error': 'Admin access required',
'message': 'This endpoint requires admin privileges' }), 403)args({ }, kwargs = None))()()
    return decorated_function

api_info = (lambda : jsonify({
'success': True,
'api': {
'name': 'Svm Panel API',
'version': 'v1',
'description': 'Comprehensive REST API for Svm Panel management',
'documentation': '/api/v1/docs',
'endpoints': {
'authentication': '/api/v1/auth/*',
'users': '/api/v1/users/*',
'vps': '/api/v1/vps/*',
'nodes': '/api/v1/nodes/*',
'system': '/api/v1/system/*' } } }))()
api_health = (lambda : jsonify({
'success': True,
'status': 'healthy',
'timestamp': datetime.now().isoformat() }))()
api_list_users = (lambda : get_db = get_dbimport hvmtry:
passexcept Exception:
None = Nonelogger.error(f'''API list users error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT id, username, email, is_admin, created_at, last_login\n                          FROM users ORDER BY id')with None:
if not :
passfor None in :
passNone, [], users = Nonerow = NoneNone(None, None)jsonify({
'success': True,
'users': users,
'count': len(users) })try:
conn = Nonecur = conn.cursor()cur.execute('SELECT id, username, email, is_admin, created_at, last_login\n                          FROM users ORDER BY id')with None:
if not :
passexcept:
passNone, None, Nonecontinue)()()
api_get_user = (lambda user_id: get_db = get_dbimport hvmtry:
passexcept Exception:
e = Nonelogger.error(f'''API get user error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT id, username, email, is_admin, created_at, last_login, last_active\n                          FROM users WHERE id = ?', (user_id,))user = cur.fetchone()if not user:
None(None, None)with None:
if not :
passNone.execute('SELECT COUNT(*) FROM vps WHERE user_id = ?', (user_id,))dict(user) = cur.fetchone()[0]user_data['vps_count'] = vps_countNone(None, None)jsonify({
'success': True,
'user': user_data })try:
conn = Nonecur = conn.cursor()cur.execute('SELECT id, username, email, is_admin, created_at, last_login, last_active\n                          FROM users WHERE id = ?', (user_id,))user = cur.fetchone()if not user:
None(None, None)with None:
if not :
passexcept:
passcontinue)()()
api_create_user = (lambda : get_db = get_dbimport hvmgenerate_password_hash = generate_password_hashimport werkzeug.securitytry:
data = request.get_json()username = data.get('username')email = data.get('email')password = data.get('password')is_admin = data.get('is_admin', False)if not username and email or password:
(jsonify({
'success': False,
'error': 'Missing required fields',
'required': [
'username',
'email',
'password'] }), 400)except Exception:
e = Nonelogger.error(f'''API create user error: {e}''')password_hash = generate_password_hash(password)now = datetime.now().isoformat()try:
conn = get_db()cur = conn.cursor()cur.execute('INSERT INTO users (username, email, password_hash, is_admin, created_at)\n                          VALUES (?, ?, ?, ?, ?)', (username, email, password_hash, 1 if is_admin else 0, now))conn.commit()user_id = cur.lastrowidwith None:
if not :
passNone(None, None)(jsonify({
'success': True,
'user_id': user_id,
'message': 'User created successfully' }), 201)try:
conn = get_db()cur = conn.cursor()cur.execute('INSERT INTO users (username, email, password_hash, is_admin, created_at)\n                          VALUES (?, ?, ?, ?, ?)', (username, email, password_hash, 1 if is_admin else 0, now))conn.commit()user_id = cur.lastrowidwith None:
if not :
passexcept:
passcontinue)()()
api_update_user = (lambda user_id: get_db = get_dbimport hvmgenerate_password_hash = generate_password_hashimport werkzeug.securitytry:
data = request.get_json()except Exception:
e = Nonelogger.error(f'''API update user error: {e}''')try:
conn = Nonecur = conn.cursor()if 'email' in data:
cur.execute('UPDATE users SET email = ? WHERE id = ?', (data['email'], user_id))if 'password' in data:
password_hash = generate_password_hash(data['password'])cur.execute('UPDATE users SET password_hash = ? WHERE id = ?', (password_hash, user_id))if 'is_admin' in data:
cur.execute('UPDATE users SET is_admin = ? WHERE id = ?', (1 if data['is_admin'] else 0, user_id))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'message': 'User updated successfully' })try:
conn = Nonecur = conn.cursor()if 'email' in data:
cur.execute('UPDATE users SET email = ? WHERE id = ?', (data['email'], user_id))if 'password' in data:
password_hash = generate_password_hash(data['password'])cur.execute('UPDATE users SET password_hash = ? WHERE id = ?', (password_hash, user_id))if 'is_admin' in data:
cur.execute('UPDATE users SET is_admin = ? WHERE id = ?', (1 if data['is_admin'] else 0, user_id))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
api_delete_user = (lambda user_id: get_db = get_dbimport hvmtry:
passexcept Exception:
e = Nonelogger.error(f'''API delete user error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('DELETE FROM users WHERE id = ?', (user_id,))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'message': 'User deleted successfully' })try:
conn = Nonecur = conn.cursor()cur.execute('DELETE FROM users WHERE id = ?', (user_id,))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
api_list_vps = (lambda : get_db = get_dbimport hvmtry:
passexcept Exception:
None = Nonelogger.error(f'''API list VPS error: {e}''')try:
conn = Nonecur = conn.cursor()if request.api_key_info['is_admin']:
cur.execute('SELECT v.*, u.username, n.name as node_name\n                              FROM vps v\n                              LEFT JOIN users u ON v.user_id = u.id\n                              LEFT JOIN nodes n ON v.node_id = n.id\n                              ORDER BY v.created_at DESC')else:
cur.execute('SELECT v.*, n.name as node_name\n                              FROM vps v\n                              LEFT JOIN nodes n ON v.node_id = n.id\n                              WHERE v.user_id = ?\n                              ORDER BY v.created_at DESC', (request.api_key_info['user_id'],))with None:
if not :
passfor None in :
passNone, [], vps_list = Nonerow = NoneNone(None, None)jsonify({
'success': True,
'vps': vps_list,
'count': len(vps_list) })try:
conn = Nonecur = conn.cursor()if request.api_key_info['is_admin']:
cur.execute('SELECT v.*, u.username, n.name as node_name\n                              FROM vps v\n                              LEFT JOIN users u ON v.user_id = u.id\n                              LEFT JOIN nodes n ON v.node_id = n.id\n                              ORDER BY v.created_at DESC')else:
cur.execute('SELECT v.*, n.name as node_name\n                              FROM vps v\n                              LEFT JOIN nodes n ON v.node_id = n.id\n                              WHERE v.user_id = ?\n                              ORDER BY v.created_at DESC', (request.api_key_info['user_id'],))with None:
if not :
passexcept:
passNone, None, Nonecontinue)()()
api_get_vps = (lambda vps_id: get_db = get_dbget_vps_by_id = get_vps_by_idrun_sync = run_syncget_container_stats = get_container_statsimport hvmtry:
vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)except Exception:
e = Nonelogger.error(f'''API get VPS error: {e}''')if None.api_key_info['is_admin'] and vps['user_id'] != request.api_key_info['user_id']:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)try:
stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))vps['stats'] = statsexcept:
vps['stats'] = Nonejsonify({
'success': True,
'vps': vps }))()()
api_create_vps = (lambda : get_db = get_dbrun_sync = run_syncexecute_lxc = execute_lxcapply_lxc_config = apply_lxc_configconfigure_container_ip = configure_container_ipapply_internal_permissions = apply_internal_permissionsimport hvmtry:
data = request.get_json()required = [
'hostname',
'user_id',
'node_id',
'os_version',
'cpu',
'ram',
'storage']for field in required:
if not field not in data:
continueNone, (jsonify({
'success': False,
'error': f'''Missing required field: {field}''',
'required': required }), 400)except Exception:
logger.error(f'''API create VPS error: {e}''')(jsonify({
'success': True,
'message': 'VPS creation started',
'note': 'Full implementation requires integration with hvm.py VPS creation logic' }), 201))()()
api_start_vps = (lambda vps_id: get_vps_by_id = get_vps_by_idrun_sync = run_syncexecute_lxc = execute_lxcimport hvmtry:
vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)except Exception:
e = Nonelogger.error(f'''API start VPS error: {e}''')if None.api_key_info['is_admin'] and vps['user_id'] != request.api_key_info['user_id']:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)run_sync(execute_lxc(vps['container_name'], f'''start {vps['container_name']}''', node_id = vps['node_id']))jsonify({
'success': True,
'message': 'VPS started successfully' }))()()
api_stop_vps = (lambda vps_id: get_vps_by_id = get_vps_by_idrun_sync = run_syncexecute_lxc = execute_lxcimport hvmtry:
vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)except Exception:
e = Nonelogger.error(f'''API stop VPS error: {e}''')if None.api_key_info['is_admin'] and vps['user_id'] != request.api_key_info['user_id']:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)run_sync(execute_lxc(vps['container_name'], f'''stop {vps['container_name']}''', node_id = vps['node_id']))jsonify({
'success': True,
'message': 'VPS stopped successfully' }))()()
api_restart_vps = (lambda vps_id: get_vps_by_id = get_vps_by_idrun_sync = run_syncexecute_lxc = execute_lxcimport hvmtry:
vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)except Exception:
e = Nonelogger.error(f'''API restart VPS error: {e}''')if None.api_key_info['is_admin'] and vps['user_id'] != request.api_key_info['user_id']:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)run_sync(execute_lxc(vps['container_name'], f'''restart {vps['container_name']}''', node_id = vps['node_id']))jsonify({
'success': True,
'message': 'VPS restarted successfully' }))()()
api_delete_vps = (lambda vps_id: get_db = get_dbget_vps_by_id = get_vps_by_idrun_sync = run_syncexecute_lxc = execute_lxcimport hvmtry:
vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)except Exception:
e = Nonelogger.error(f'''API delete VPS error: {e}''')try:
run_sync(execute_lxc(vps['container_name'], f'''delete {vps['container_name']} --force''', node_id = vps['node_id']))except:
passtry:
conn = get_db()cur = conn.cursor()cur.execute('DELETE FROM vps WHERE id = ?', (vps_id,))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'message': 'VPS deleted successfully' })try:
conn = get_db()cur = conn.cursor()cur.execute('DELETE FROM vps WHERE id = ?', (vps_id,))conn.commit()with None:
if not :
passexcept:
passget_db()continue)()()
api_list_nodes = (lambda : get_nodes = get_nodesimport hvmtry:
nodes = get_nodes()except Exception:
e = Nonelogger.error(f'''API list nodes error: {e}'''))()()
api_get_node = (lambda node_id: get_node = get_noderun_sync = run_syncget_host_stats = get_host_statsimport hvmtry:
node = get_node(node_id)if not node:
(jsonify({
'success': False,
'error': 'Node not found' }), 404)except Exception:
e = Nonelogger.error(f'''API get node error: {e}''')try:
stats = run_sync(get_host_stats(node_id))node['stats'] = statsexcept:
node['stats'] = Nonejsonify({
'success': True,
'node': node }))()()
api_system_info = (lambda : get_host_cpu_usage = get_host_cpu_usageget_host_ram_usage = get_host_ram_usageget_host_disk_usage = get_host_disk_usageget_host_uptime = get_host_uptimeimport hvmimport platformtry:
system_info = {
'hostname': platform.node(),
'platform': platform.platform(),
'python_version': platform.python_version(),
'cpu': {
'cores': __import__('os').cpu_count(),
'usage': get_host_cpu_usage() },
'memory': get_host_ram_usage(),
'disk': get_host_disk_usage(),
'uptime': get_host_uptime() }except Exception:
e = Nonelogger.error(f'''API system info error: {e}'''))()()
api_system_stats = (lambda : get_db = get_dbimport hvmtry:
passexcept Exception:
e = Nonelogger.error(f'''API system stats error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT COUNT(*) FROM users')total_users = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM vps')total_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM vps WHERE status = "running"')running_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM nodes')total_nodes = cur.fetchone()[0]with None:
if not :
passNone(None, None)jsonify({
'success': True,
'stats': {
'users': total_users,
'vps': {
'total': total_vps,
'running': running_vps,
'stopped': total_vps - running_vps },
'nodes': total_nodes } })try:
conn = Nonecur = conn.cursor()cur.execute('SELECT COUNT(*) FROM users')total_users = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM vps')total_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM vps WHERE status = "running"')running_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM nodes')total_nodes = cur.fetchone()[0]with None:
if not :
passexcept:
passcontinue)()()
api_suspend_vps = (lambda vps_id: get_db = get_dbget_vps_by_id = get_vps_by_idrun_sync = run_syncexecute_lxc = execute_lxcimport hvmtry:
if not request.get_json():
request.get_json()data = { }reason = data.get('reason', 'Suspended by admin via API')vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)except Exception:
e = Nonelogger.error(f'''API suspend VPS error: {e}''')try:
run_sync(execute_lxc(vps['container_name'], f'''stop {vps['container_name']} --force''', node_id = vps['node_id']))except:
passtry:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE vps SET suspended = 1, suspended_reason = ?, status = "stopped" WHERE id = ?', (reason, vps_id))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'message': 'VPS suspended successfully' })try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE vps SET suspended = 1, suspended_reason = ?, status = "stopped" WHERE id = ?', (reason, vps_id))conn.commit()with None:
if not :
passexcept:
passget_db()continue)()()
api_unsuspend_vps = (lambda vps_id: get_db = get_dbimport hvmtry:
passexcept Exception:
e = Nonelogger.error(f'''API unsuspend VPS error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('UPDATE vps SET suspended = 0, suspended_reason = NULL WHERE id = ?', (vps_id,))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'message': 'VPS unsuspended successfully' })try:
conn = Nonecur = conn.cursor()cur.execute('UPDATE vps SET suspended = 0, suspended_reason = NULL WHERE id = ?', (vps_id,))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
api_resize_vps = (lambda vps_id: get_db = get_dbget_vps_by_id = get_vps_by_idimport hvmtry:
if not request.get_json():
request.get_json()data = { }vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)except Exception:
e = Nonelogger.error(f'''API resize VPS error: {e}''')try:
conn = get_db()cur = conn.cursor()if 'cpu' in data:
cur.execute('UPDATE vps SET cpu = ? WHERE id = ?', (data['cpu'], vps_id))if 'ram' in data:
cur.execute('UPDATE vps SET ram = ? WHERE id = ?', (data['ram'], vps_id))if 'storage' in data:
cur.execute('UPDATE vps SET storage = ? WHERE id = ?', (data['storage'], vps_id))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'message': 'VPS resized successfully (restart required for changes to take effect)' })try:
conn = get_db()cur = conn.cursor()if 'cpu' in data:
cur.execute('UPDATE vps SET cpu = ? WHERE id = ?', (data['cpu'], vps_id))if 'ram' in data:
cur.execute('UPDATE vps SET ram = ? WHERE id = ?', (data['ram'], vps_id))if 'storage' in data:
cur.execute('UPDATE vps SET storage = ? WHERE id = ?', (data['storage'], vps_id))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
api_execute_command = (lambda vps_id: get_vps_by_id = get_vps_by_idrun_sync = run_syncexecute_lxc = execute_lxcimport hvmtry:
if not request.get_json():
request.get_json()data = { }command = data.get('command')if not command:
(jsonify({
'success': False,
'error': 'command required' }), 400)except Exception:
e = Nonelogger.error(f'''API execute command error: {e}''')vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)if None.api_key_info['is_admin'] and vps['user_id'] != request.api_key_info['user_id']:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)result = run_sync(execute_lxc(vps['container_name'], f'''exec {vps['container_name']} -- {command}''', node_id = vps['node_id']))jsonify({
'success': True,
'output': result }))()()
api_create_node = (lambda : get_db = get_dbimport hvmtry:
if not request.get_json():
request.get_json()data = { }name = data.get('name')url = data.get('url')location = data.get('location', '')api_key = data.get('api_key')if not name or url:
(jsonify({
'success': False,
'error': 'Missing required fields',
'required': [
'name',
'url'] }), 400)except Exception:
e = Nonelogger.error(f'''API create node error: {e}''')now = None.now().isoformat()try:
conn = get_db()cur = conn.cursor()cur.execute('INSERT INTO nodes (name, url, location, api_key, created_at, updated_at)\n                          VALUES (?, ?, ?, ?, ?, ?)', (name, url, location, api_key, now, now))conn.commit()node_id = cur.lastrowidwith None:
if not :
passNone(None, None)(jsonify({
'success': True,
'node_id': node_id,
'message': 'Node created successfully' }), 201)try:
conn = get_db()cur = conn.cursor()cur.execute('INSERT INTO nodes (name, url, location, api_key, created_at, updated_at)\n                          VALUES (?, ?, ?, ?, ?, ?)', (name, url, location, api_key, now, now))conn.commit()node_id = cur.lastrowidwith None:
if not :
passexcept:
passcontinue)()()
api_update_node = (lambda node_id: get_db = get_dbimport hvmtry:
if not request.get_json():
request.get_json()data = { }except Exception:
e = Nonelogger.error(f'''API update node error: {e}''')try:
conn = Nonecur = conn.cursor()if 'name' in data:
cur.execute('UPDATE nodes SET name = ? WHERE id = ?', (data['name'], node_id))if 'url' in data:
cur.execute('UPDATE nodes SET url = ? WHERE id = ?', (data['url'], node_id))if 'location' in data:
cur.execute('UPDATE nodes SET location = ? WHERE id = ?', (data['location'], node_id))if 'api_key' in data:
cur.execute('UPDATE nodes SET api_key = ? WHERE id = ?', (data['api_key'], node_id))cur.execute('UPDATE nodes SET updated_at = ? WHERE id = ?', (datetime.now().isoformat(), node_id))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'message': 'Node updated successfully' })try:
conn = Nonecur = conn.cursor()if 'name' in data:
cur.execute('UPDATE nodes SET name = ? WHERE id = ?', (data['name'], node_id))if 'url' in data:
cur.execute('UPDATE nodes SET url = ? WHERE id = ?', (data['url'], node_id))if 'location' in data:
cur.execute('UPDATE nodes SET location = ? WHERE id = ?', (data['location'], node_id))if 'api_key' in data:
cur.execute('UPDATE nodes SET api_key = ? WHERE id = ?', (data['api_key'], node_id))cur.execute('UPDATE nodes SET updated_at = ? WHERE id = ?', (datetime.now().isoformat(), node_id))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
api_delete_node = (lambda node_id: get_db = get_dbimport hvmtry:
passexcept Exception:
e = Nonelogger.error(f'''API delete node error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('DELETE FROM nodes WHERE id = ?', (node_id,))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'message': 'Node deleted successfully' })try:
conn = Nonecur = conn.cursor()cur.execute('DELETE FROM nodes WHERE id = ?', (node_id,))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
api_get_settings = (lambda : get_db = get_dbimport hvmtry:
passexcept Exception:
None = Nonelogger.error(f'''API get settings error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT key, value, description FROM settings')with None:
if not :
passfor None in :
passNone = None, { }row = NoneNone(None, None)jsonify({
'success': True,
'settings': settings })try:
conn = Nonecur = conn.cursor()cur.execute('SELECT key, value, description FROM settings')with None:
if not :
passexcept:
passNone, None, Nonecontinue)()()
api_get_setting = (lambda key: get_setting = get_settingimport hvmtry:
value = get_setting(key)if value:
(jsonify({
'success': False,
'error': 'Setting not found' }), 404)except Exception:
e = Nonelogger.error(f'''API get setting error: {e}''')None({
'success': True,
'key': key,
'value': value }))()()
api_update_setting = (lambda key: set_setting = set_settingimport hvmtry:
if not request.get_json():
request.get_json()data = { }value = data.get('value')if value:
(jsonify({
'success': False,
'error': 'value required' }), 400)except Exception:
e = Nonelogger.error(f'''API update setting error: {e}''')set_setting(key, str(value))jsonify({
'success': True,
'message': 'Setting updated successfully' }))()()
api_enable_maintenance = (lambda : set_setting = set_settingimport hvmtry:
if not request.get_json():
request.get_json()data = { }message = data.get('message', 'Site is under maintenance. Please check back later.')set_setting('maintenance_mode', '1')set_setting('maintenance_message', message)except Exception:
e = Nonelogger.error(f'''API enable maintenance error: {e}'''))()()
api_disable_maintenance = (lambda : set_setting = set_settingimport hvmtry:
set_setting('maintenance_mode', '0')except Exception:
e = Nonelogger.error(f'''API disable maintenance error: {e}'''))()()
api_bulk_start_vps = (lambda : get_db = get_dbrun_sync = run_syncexecute_lxc = execute_lxcimport hvmtry:
if not request.get_json():
request.get_json()data = { }vps_ids = data.get('vps_ids', [])if not vps_ids:
(jsonify({
'success': False,
'error': 'vps_ids required' }), 400)except Exception:
e = Nonelogger.error(f'''API bulk start VPS error: {e}''')started = Nonefailed = []try:
conn = get_db()cur = conn.cursor()for vps_id in vps_ids:
cur.execute('SELECT * FROM vps WHERE id = ?', (vps_id,))vps = cur.fetchone()if not vps:
continuetry:
run_sync(execute_lxc(vps['container_name'], f'''start {vps['container_name']}''', node_id = vps['node_id']))started.append(vps_id)except Exception:
e = Nonefailed.append({
'vps_id': vps_id,
'error': str(e) })with None:
if not :
passNone(None, None)jsonify({
'success': True,
'started': started,
'failed': failed,
'message': f'''Started {len(started)} VPS, {len(failed)} failed''' })try:
conn = get_db()cur = conn.cursor()for vps_id in vps_ids:
cur.execute('SELECT * FROM vps WHERE id = ?', (vps_id,))vps = cur.fetchone()if not vps:
continuetry:
run_sync(execute_lxc(vps['container_name'], f'''start {vps['container_name']}''', node_id = vps['node_id']))started.append(vps_id)except Exception:
e = Nonefailed.append({
'vps_id': vps_id,
'error': str(e) })with None:
if not :
passexcept:
passcontinue)()()
api_bulk_stop_vps = (lambda : get_db = get_dbrun_sync = run_syncexecute_lxc = execute_lxcimport hvmtry:
if not request.get_json():
request.get_json()data = { }vps_ids = data.get('vps_ids', [])if not vps_ids:
(jsonify({
'success': False,
'error': 'vps_ids required' }), 400)except Exception:
e = Nonelogger.error(f'''API bulk stop VPS error: {e}''')stopped = Nonefailed = []try:
conn = get_db()cur = conn.cursor()for vps_id in vps_ids:
cur.execute('SELECT * FROM vps WHERE id = ?', (vps_id,))vps = cur.fetchone()if not vps:
continuetry:
run_sync(execute_lxc(vps['container_name'], f'''stop {vps['container_name']}''', node_id = vps['node_id']))stopped.append(vps_id)except Exception:
e = Nonefailed.append({
'vps_id': vps_id,
'error': str(e) })with None:
if not :
passNone(None, None)jsonify({
'success': True,
'stopped': stopped,
'failed': failed,
'message': f'''Stopped {len(stopped)} VPS, {len(failed)} failed''' })try:
conn = get_db()cur = conn.cursor()for vps_id in vps_ids:
cur.execute('SELECT * FROM vps WHERE id = ?', (vps_id,))vps = cur.fetchone()if not vps:
continuetry:
run_sync(execute_lxc(vps['container_name'], f'''stop {vps['container_name']}''', node_id = vps['node_id']))stopped.append(vps_id)except Exception:
e = Nonefailed.append({
'vps_id': vps_id,
'error': str(e) })with None:
if not :
passexcept:
passcontinue)()()
api_list_ports = (lambda : get_db = get_dbimport hvmtry:
passexcept Exception:
None = Nonelogger.error(f'''API list ports error: {e}''')try:
conn = Nonecur = conn.cursor()if request.api_key_info['is_admin']:
cur.execute('SELECT pf.*, v.hostname, u.username\n                              FROM port_forwards pf\n                              LEFT JOIN vps v ON pf.vps_id = v.id\n                              LEFT JOIN users u ON pf.user_id = u.id\n                              ORDER BY pf.created_at DESC')else:
cur.execute('SELECT pf.*, v.hostname\n                              FROM port_forwards pf\n                              LEFT JOIN vps v ON pf.vps_id = v.id\n                              WHERE pf.user_id = ?\n                              ORDER BY pf.created_at DESC', (request.api_key_info['user_id'],))with None:
if not :
passfor None in :
passNone, [], ports = Nonerow = NoneNone(None, None)jsonify({
'success': True,
'ports': ports,
'count': len(ports) })try:
conn = Nonecur = conn.cursor()if request.api_key_info['is_admin']:
cur.execute('SELECT pf.*, v.hostname, u.username\n                              FROM port_forwards pf\n                              LEFT JOIN vps v ON pf.vps_id = v.id\n                              LEFT JOIN users u ON pf.user_id = u.id\n                              ORDER BY pf.created_at DESC')else:
cur.execute('SELECT pf.*, v.hostname\n                              FROM port_forwards pf\n                              LEFT JOIN vps v ON pf.vps_id = v.id\n                              WHERE pf.user_id = ?\n                              ORDER BY pf.created_at DESC', (request.api_key_info['user_id'],))with None:
if not :
passexcept:
passNone, None, Nonecontinue)()()
api_create_port = (lambda : get_db = get_dballocate_port = allocate_portimport hvmtry:
if not request.get_json():
request.get_json()data = { }vps_id = data.get('vps_id')internal_port = data.get('internal_port')protocol = data.get('protocol', 'tcp')description = data.get('description', '')if not vps_id or internal_port:
(jsonify({
'success': False,
'error': 'Missing required fields',
'required': [
'vps_id',
'internal_port'] }), 400)except Exception:
None = Nonelogger.error(f'''API create port error: {e}''')try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT user_id FROM vps WHERE id = ?', (vps_id,))vps = cur.fetchone()if not vps:
None(None, None)with None:
if not :
passif get_db().api_key_info['is_admin'] and vps['user_id'] != request.api_key_info['user_id']:
None(None, None)None(None, None)if not external_port:
(jsonify({
'success': False,
'error': 'No ports available' }), 400)(allocate_port(request.api_key_info['user_id'], vps_id, internal_port, protocol, description)({
'success': True,
'external_port': external_port,
'message': 'Port forward created successfully' }), 201)try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT user_id FROM vps WHERE id = ?', (vps_id,))vps = cur.fetchone()if not vps:
None(None, None)with None:
if not :
passexcept:
passcontinue)()()
api_delete_port = (lambda port_id: get_db = get_dbimport hvmtry:
passexcept Exception:
logger.error(f'''API delete port error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT user_id FROM port_forwards WHERE id = ?', (port_id,))port = cur.fetchone()if not port:
None(None, None)with None:
if not :
passif None.api_key_info['is_admin'] and port['user_id'] != request.api_key_info['user_id']:
None(None, None)None.execute('DELETE FROM port_forwards WHERE id = ?', (port_id,))conn.commit()None(None, None)jsonify({
'success': True,
'message': 'Port forward deleted successfully' })try:
conn = Nonecur = conn.cursor()cur.execute('SELECT user_id FROM port_forwards WHERE id = ?', (port_id,))port = cur.fetchone()if not port:
None(None, None)with None:
if not :
passexcept:
passcontinue)()()
api_list_notifications = (lambda : get_db = get_dbimport hvmtry:
page = request.args.get('page', 1, type = int)per_page = request.args.get('per_page', 20, type = int)unread_only = request.args.get('unread_only', 'false').lower() == 'true'offset = (page - 1) * per_pageexcept Exception:
None = Nonelogger.error(f'''API list notifications error: {e}''')try:
conn = Nonecur = conn.cursor()query = 'SELECT * FROM notifications WHERE user_id = ?'params = [
request.api_key_info['user_id']]if unread_only:
query += ' AND is_read = 0'query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'params.extend([
per_page,
offset])cur.execute(query, params)with None:
if not :
passfor None in :
passNone, [], notifications = Nonerow = Nonecount_query = 'SELECT COUNT(*) FROM notifications WHERE user_id = ?'count_params = [
request.api_key_info['user_id']]if unread_only:
count_query += ' AND is_read = 0'cur.execute(count_query, count_params)total = cur.fetchone()[0]None(None, None)jsonify({
'success': True,
'notifications': notifications,
'pagination': {
'page': page,
'per_page': per_page,
'total': total,
'pages': (total + per_page - 1) // per_page } })try:
conn = Nonecur = conn.cursor()query = 'SELECT * FROM notifications WHERE user_id = ?'params = [
request.api_key_info['user_id']]if unread_only:
query += ' AND is_read = 0'query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'params.extend([
per_page,
offset])cur.execute(query, params)with None:
if not :
passexcept:
passNone, None, Nonecontinue)()()
api_mark_notification_read = (lambda notification_id: get_db = get_dbimport hvmtry:
passexcept Exception:
logger.error(f'''API mark notification read error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT user_id FROM notifications WHERE id = ?', (notification_id,))notif = cur.fetchone()if not notif:
None(None, None)with None:
if not :
passif None['user_id'] != request.api_key_info['user_id']:
None(None, None)None.execute('UPDATE notifications SET is_read = 1 WHERE id = ?', (notification_id,))conn.commit()None(None, None)jsonify({
'success': True,
'message': 'Notification marked as read' })try:
conn = Nonecur = conn.cursor()cur.execute('SELECT user_id FROM notifications WHERE id = ?', (notification_id,))notif = cur.fetchone()if not notif:
None(None, None)with None:
if not :
passexcept:
passcontinue)()()
api_mark_all_notifications_read = (lambda : get_db = get_dbimport hvmtry:
passexcept Exception:
e = Nonelogger.error(f'''API mark all notifications read error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('UPDATE notifications SET is_read = 1 WHERE user_id = ?', (request.api_key_info['user_id'],))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'message': 'All notifications marked as read' })try:
conn = Nonecur = conn.cursor()cur.execute('UPDATE notifications SET is_read = 1 WHERE user_id = ?', (request.api_key_info['user_id'],))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
api_list_activity = (lambda : get_db = get_dbimport hvmtry:
page = request.args.get('page', 1, type = int)per_page = request.args.get('per_page', 50, type = int)offset = (page - 1) * per_pageexcept Exception:
None = Nonelogger.error(f'''API list activity error: {e}''')try:
conn = Nonecur = conn.cursor()if request.api_key_info['is_admin']:
cur.execute('SELECT al.*, u.username\n                              FROM activity_log al\n                              LEFT JOIN users u ON al.user_id = u.id\n                              ORDER BY al.timestamp DESC\n                              LIMIT ? OFFSET ?', (per_page, offset))cur.execute('SELECT COUNT(*) FROM activity_log')else:
cur.execute('SELECT * FROM activity_log\n                              WHERE user_id = ?\n                              ORDER BY timestamp DESC\n                              LIMIT ? OFFSET ?', (request.api_key_info['user_id'], per_page, offset))cur.execute('SELECT COUNT(*) FROM activity_log WHERE user_id = ?', (request.api_key_info['user_id'],))with None:
if not :
passfor None in :
passNone, [], activities = Nonerow = Nonetotal = cur.fetchone()[0]None(None, None)jsonify({
'success': True,
'activities': activities,
'pagination': {
'page': page,
'per_page': per_page,
'total': total,
'pages': (total + per_page - 1) // per_page } })try:
conn = Nonecur = conn.cursor()if request.api_key_info['is_admin']:
cur.execute('SELECT al.*, u.username\n                              FROM activity_log al\n                              LEFT JOIN users u ON al.user_id = u.id\n                              ORDER BY al.timestamp DESC\n                              LIMIT ? OFFSET ?', (per_page, offset))cur.execute('SELECT COUNT(*) FROM activity_log')else:
cur.execute('SELECT * FROM activity_log\n                              WHERE user_id = ?\n                              ORDER BY timestamp DESC\n                              LIMIT ? OFFSET ?', (request.api_key_info['user_id'], per_page, offset))cur.execute('SELECT COUNT(*) FROM activity_log WHERE user_id = ?', (request.api_key_info['user_id'],))with None:
if not :
passexcept:
passNone, None, Nonecontinue)()()
api_get_vps_password = (lambda vps_id: get_vps_by_id = get_vps_by_idimport hvmtry:
vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)except Exception:
e = Nonelogger.error(f'''API get VPS password error: {e}''')if None.api_key_info['is_admin'] and vps['user_id'] != request.api_key_info['user_id']:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)password = None.get('root_password', 'root')jsonify({
'success': True,
'password': password }))()()
api_change_vps_password = (lambda vps_id: get_db = get_dbget_vps_by_id = get_vps_by_idrun_sync = run_syncexecute_lxc = execute_lxcimport hvmimport platformtry:
if not request.get_json():
request.get_json()data = { }new_password = data.get('password')if not new_password:
(jsonify({
'success': False,
'error': 'password required' }), 400)except Exception:
e = Nonelogger.error(f'''API change VPS password error: {e}''')vps = get_vps_by_id(vps_id)if not vps:
(jsonify({
'success': False,
'error': 'VPS not found' }), 404)if None.api_key_info['is_admin'] and vps['user_id'] != request.api_key_info['user_id']:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE vps SET root_password = ? WHERE id = ?', (new_password, vps_id))conn.commit()None(None, None)if platform.system() == 'Linux' and vps.get('status') == 'running':
try:
cmd = f'''exec {vps['container_name']} -- bash -c "echo \'root:{new_password}\' | chpasswd"'''run_sync(execute_lxc(vps['container_name'], cmd, node_id = vps['node_id']))except:
passjsonify({
'success': True,
'message': 'Password changed successfully' })with None:
if not get_db():
passcontinue)()()
api_list_api_keys = (lambda : get_db = get_dbimport hvmtry:
passexcept Exception:
None = Nonelogger.error(f'''API list API keys error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT ak.*, u.username\n                          FROM api_keys ak\n                          JOIN users u ON ak.user_id = u.id\n                          ORDER BY ak.created_at DESC')with None:
if not :
passfor None in :
passNone, [], keys = Nonerow = NoneNone(None, None)jsonify({
'success': True,
'api_keys': keys,
'count': len(keys) })try:
conn = Nonecur = conn.cursor()cur.execute('SELECT ak.*, u.username\n                          FROM api_keys ak\n                          JOIN users u ON ak.user_id = u.id\n                          ORDER BY ak.created_at DESC')with None:
if not :
passexcept:
passNone, None, Nonecontinue)()()
api_create_api_key = (lambda : get_db = get_dbimport hvmtry:
if not request.get_json():
request.get_json()data = { }name = data.get('name', 'API Key')user_id = data.get('user_id')if not user_id:
(jsonify({
'success': False,
'error': 'user_id required' }), 400)except Exception:
None = Nonelogger.error(f'''API create API key error: {e}''')new_key = None.token_urlsafe(32)now = datetime.now().isoformat()try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT id FROM users WHERE id = ?', (user_id,))if not cur.fetchone():
None(None, None)with None:
if not :
passget_db().execute('INSERT INTO api_keys (user_id, name, key, is_active, created_at)\n                          VALUES (?, ?, ?, 1, ?)', (user_id, name, new_key, now))conn.commit()None(None, None)(jsonify({
'success': True,
'api_key': {
'id': key_id,
'name': name,
'key': new_key,
'user_id': user_id },
'message': 'API key created successfully' }), 201)try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT id FROM users WHERE id = ?', (user_id,))if not cur.fetchone():
None(None, None)with None:
if not :
passexcept:
passcontinue)()()
api_delete_api_key = (lambda key_id: get_db = get_dbimport hvmtry:
passexcept Exception:
logger.error(f'''API delete API key error: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT user_id FROM api_keys WHERE id = ?', (key_id,))key = cur.fetchone()if not key:
None(None, None)with None:
if not :
passNone.execute('DELETE FROM api_keys WHERE id = ?', (key_id,))conn.commit()None(None, None)jsonify({
'success': True,
'message': 'API key deleted successfully' })try:
conn = Nonecur = conn.cursor()cur.execute('SELECT user_id FROM api_keys WHERE id = ?', (key_id,))key = cur.fetchone()if not key:
None(None, None)with None:
if not :
passexcept:
passcontinue)()()
api_stats_overview = (lambda : get_db = get_dbimport hvmtry:
passexcept Exception:
e = Nonelogger.error(f'''API stats overview error: {e}''')try:
conn = Nonecur = conn.cursor()if request.api_key_info['is_admin']:
cur.execute('SELECT COUNT(*) FROM users')total_users = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM vps')total_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM vps WHERE status = "running"')running_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM vps WHERE suspended = 1')suspended_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM nodes')total_nodes = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM port_forwards')total_ports = cur.fetchone()[0]stats = {
'users': total_users,
'vps': {
'total': total_vps,
'running': running_vps,
'stopped': total_vps - running_vps - suspended_vps,
'suspended': suspended_vps },
'nodes': total_nodes,
'ports': total_ports }else:
user_id = request.api_key_info['user_id']cur.execute('SELECT COUNT(*) FROM vps WHERE user_id = ?', (user_id,))total_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM vps WHERE user_id = ? AND status = "running"', (user_id,))running_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM vps WHERE user_id = ? AND suspended = 1', (user_id,))suspended_vps = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM port_forwards WHERE user_id = ?', (user_id,))total_ports = cur.fetchone()[0]cur.execute('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', (user_id,))unread_notifications = cur.fetchone()[0]stats = {
'vps': {
'total': total_vps,
'running': running_vps,
'stopped': total_vps - running_vps - suspended_vps,
'suspended': suspended_vps },
'ports': total_ports,
'notifications': {
'unread': unread_notifications } }None(None, None)jsonify({
'success': True,
'stats': stats })with None:
if not None:
passcontinue)()()
api_documentation = (lambda : docs = {
'api': {
'name': 'Svm Panel API',
'version': 'v1',
'base_url': '/api/v1',
'authentication': 'API Key (X-API-Key header or api_key parameter)' },
'endpoints': {
'info': {
'GET /info': 'Get API information',
'GET /health': 'Health check' },
'users': {
'GET /users': 'List all users (admin)',
'GET /users/<id>': 'Get user details (admin)',
'POST /users': 'Create user (admin)',
'PUT /users/<id>': 'Update user (admin)',
'DELETE /users/<id>': 'Delete user (admin)' },
'vps': {
'GET /vps': 'List VPS',
'GET /vps/<id>': 'Get VPS details',
'POST /vps': 'Create VPS (admin)',
'DELETE /vps/<id>': 'Delete VPS (admin)',
'POST /vps/<id>/start': 'Start VPS',
'POST /vps/<id>/stop': 'Stop VPS',
'POST /vps/<id>/restart': 'Restart VPS',
'POST /vps/<id>/suspend': 'Suspend VPS (admin)',
'POST /vps/<id>/unsuspend': 'Unsuspend VPS (admin)',
'POST /vps/<id>/resize': 'Resize VPS (admin)',
'POST /vps/<id>/execute': 'Execute command in VPS',
'GET /vps/<id>/password': 'Get VPS password',
'POST /vps/<id>/password': 'Change VPS password' },
'ports': {
'GET /ports': 'List port forwards',
'POST /ports': 'Create port forward',
'DELETE /ports/<id>': 'Delete port forward' },
'nodes': {
'GET /nodes': 'List nodes (admin)',
'GET /nodes/<id>': 'Get node details (admin)',
'POST /nodes': 'Create node (admin)',
'PUT /nodes/<id>': 'Update node (admin)',
'DELETE /nodes/<id>': 'Delete node (admin)' },
'notifications': {
'GET /notifications': 'List notifications',
'POST /notifications/<id>/read': 'Mark notification as read',
'POST /notifications/read-all': 'Mark all notifications as read' },
'activity': {
'GET /activity': 'List activity logs' },
'api_keys': {
'GET /api-keys': 'List API keys',
'POST /api-keys': 'Create API key',
'DELETE /api-keys/<id>': 'Delete API key' },
'settings': {
'GET /settings': 'Get all settings (admin)',
'GET /settings/<key>': 'Get setting (admin)',
'PUT /settings/<key>': 'Update setting (admin)' },
'maintenance': {
'POST /maintenance/enable': 'Enable maintenance mode (admin)',
'POST /maintenance/disable': 'Disable maintenance mode (admin)' },
'system': {
'GET /system/info': 'Get system information (admin)',
'GET /system/stats': 'Get system statistics (admin)' },
'statistics': {
'GET /stats/overview': 'Get overview statistics' },
'bulk_operations': {
'POST /vps/bulk/start': 'Start multiple VPS (admin)',
'POST /vps/bulk/stop': 'Stop multiple VPS (admin)' } },
'examples': {
'authentication': 'curl -H "X-API-Key: your_api_key" https://panel.example.com/api/v1/vps',
'create_port': 'curl -X POST -H "X-API-Key: your_api_key" -H "Content-Type: application/json" -d \'{"vps_id": 1, "internal_port": 80, "protocol": "tcp"}\' https://panel.example.com/api/v1/ports',
'start_vps': 'curl -X POST -H "X-API-Key: your_api_key" https://panel.example.com/api/v1/vps/1/start' } }jsonify({
'success': True,
'documentation': docs }))()
api_not_found = (lambda error: (jsonify({
'success': False,
'error': 'Endpoint not found',
'message': 'The requested API endpoint does not exist' }), 404))()
api_method_not_allowed = (lambda error: (jsonify({
'success': False,
'error': 'Method not allowed',
'message': 'The HTTP method is not allowed for this endpoint' }), 405))()
api_internal_error = (lambda error: (jsonify({
'success': False,
'error': 'Internal server error',
'message': 'An unexpected error occurred' }), 500))()
