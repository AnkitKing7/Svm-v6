# Source Generated with Decompyle++
# File: hvm.pyc (Python 3.12)

import os
import sys
import json
import time
import shlex
import shutil
import asyncio
import sqlite3
import random
import threading
import logging
import subprocess
import ipaddress
import socket
import requests
import urllib3
import secrets
import hashlib
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import hmac
import base64
import uuid
import re
from datetime import datetime, timedelta
from datetime import timezone
from typing import Optional, List, Dict, Any, Tuple, Union
from functools import wraps
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlencode, parse_qs
import flask
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash, send_file, send_from_directory, make_response, current_app, abort
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage

try:
    from flask_socketio import SocketIO, emit, join_room, leave_room
    SOCKETIO_AVAILABLE = True
except ImportError:
    app.template_filter('truncate')
    SOCKETIO_AVAILABLE = False
    print('Warning: flask-socketio not installed, real-time features disabled')


try:
    import paramiko
    SSH_AVAILABLE = True
except ImportError:
    app.template_filter('get_os_icon')
    SSH_AVAILABLE = False
    print('Warning: paramiko not installed, SSH console disabled')


try:
    from hypercorn.asyncio import serve
    from hypercorn.config import Config as HyperConfig
    HYPERCORN_AVAILABLE = True
except ImportError:
    app.template_filter('format_bytes')
    HYPERCORN_AVAILABLE = False
    print('Warning: hypercorn not installed, using Flask development server')


try:
    from asgiref.wsgi import WsgiToAsgi
    ASGIREF_AVAILABLE = True
except ImportError:
    app.template_filter('truncate')
    ASGIREF_AVAILABLE = False
    print('Warning: asgiref not installed, ASGI support disabled')


try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    app.template_filter('get_os_icon')
    PIL_AVAILABLE = False
    Image = None
    logging.warning('PIL not installed - image optimization disabled')

PANEL_NAME = os.getenv('PANEL_NAME', 'SVM PANEL')
PANEL_VERSION = os.getenv('PANEL_VERSION', '6.0-PRO-ULTIMATE')
PANEL_DEVELOPER = os.getenv('PANEL_DEVELOPER', 'AnkitCoder')
SECRET_KEY = os.getenv('SECRET_KEY', secrets.token_urlsafe(32))
DATABASE_PATH = os.getenv('DATABASE_PATH', 'svm.db')
HOST = os.getenv('HOST', '0.0.0.0')
PORT = int(os.getenv('PORT', 5000))
MAIN_ADMIN_USERNAME = os.getenv('MAIN_ADMIN_USERNAME', 'admin')
MAIN_ADMIN_PASSWORD = os.getenv('MAIN_ADMIN_PASSWORD', 'admin')
MAIN_ADMIN_EMAIL = os.getenv('MAIN_ADMIN_EMAIL', 'admin@localhost')
YOUR_SERVER_IP = os.getenv('YOUR_SERVER_IP', socket.gethostbyname(socket.gethostname()))
DEFAULT_STORAGE_POOL = os.getenv('DEFAULT_STORAGE_POOL', 'default')
DEBUG_MODE = os.getenv('DEBUG_MODE', 'False').lower() == 'true'
AUTO_BACKUP_INTERVAL = int(os.getenv('AUTO_BACKUP_INTERVAL', 3600))
STATS_UPDATE_INTERVAL = int(os.getenv('STATS_UPDATE_INTERVAL', 5))
OS_OPTIONS = [
    {
        'label': 'Ubuntu 20.04 LTS',
        'value': 'ubuntu:20.04',
        'version': '20.04',
        'icon': 'ubuntu' },
    {
        'label': 'Ubuntu 22.04 LTS',
        'value': 'ubuntu:22.04',
        'version': '22.04',
        'icon': 'ubuntu' },
    {
        'label': 'Ubuntu 24.04 LTS',
        'value': 'ubuntu:24.04',
        'version': '24.04',
        'icon': 'ubuntu' },
    {
        'label': 'Debian 10 (Buster)',
        'value': 'images:debian/10',
        'version': '10',
        'icon': 'debian' },
    {
        'label': 'Debian 11 (Bullseye)',
        'value': 'images:debian/11',
        'version': '11',
        'icon': 'debian' },
    {
        'label': 'Debian 12 (Bookworm)',
        'value': 'images:debian/12',
        'version': '12',
        'icon': 'debian' },
    {
        'label': 'Debian 13 (Trixie)',
        'value': 'images:debian/13',
        'version': '13',
        'icon': 'debian' }]
OS_ICONS = {
    'ubuntu': 'fab fa-ubuntu',
    'debian': 'fab fa-debian',
    'centos': 'fab fa-centos',
    'alpine': 'fas fa-mountain',
    'fedora': 'fab fa-fedora',
    'rocky': 'fas fa-mountain',
    'default': 'fab fa-linux' }
logging.basicConfig(level = logging.INFO, format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s', handlers = [
    logging.FileHandler('svm.log'),
    logging.StreamHandler()])
logger = logging.getLogger('hvm_panel')
app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['SESSION_TYPE'] = 'filesystem'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days = 1)
app.config['MAX_CONTENT_LENGTH'] = 16777216
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {
    'gif',
    'ico',
    'jpg',
    'png',
    'svg',
    'jpeg',
    'webp'}
app.config['MAX_IMAGE_SIZE'] = 5242880
app.wsgi_app = ProxyFix(app.wsgi_app, x_for = 1, x_proto = 1, x_host = 1, x_port = 1)
if SOCKETIO_AVAILABLE:
    socketio = SocketIO(app, cors_allowed_origins = '*', async_mode = 'threading', ping_timeout = 60, ping_interval = 25)
else:
    socketio = None
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'warning'
active_consoles = { }
active_consoles_lock = threading.Lock()
get_db = (lambda : if None:
passconn = Nonetry:
conn = sqlite3.connect(DATABASE_PATH, timeout = 30)conn.execute('PRAGMA journal_mode=WAL')conn.execute('PRAGMA foreign_keys=ON')conn.execute('PRAGMA busy_timeout=30000')conn.row_factory = sqlite3.Rowif conn:
passconn.commit()except Exception:
e = Noneif conn:
conn.rollback()logger.error(f'''Database error: {e}''')raise e = Nonedel etry:
passif conn:
except:
passtry:
passif conn:
except:
passif conn:
conn.close()NoneNonetry:
conn = sqlite3.connect(DATABASE_PATH, timeout = 30)conn.execute('PRAGMA journal_mode=WAL')conn.execute('PRAGMA foreign_keys=ON')conn.execute('PRAGMA busy_timeout=30000')conn.row_factory = sqlite3.Rowif conn:
passconn.commit()except Exception:
e = Noneif conn:
conn.rollback()logger.error(f'''Database error: {e}''')raise e = Nonedel etry:
passif conn:
except:
passtry:
passif conn:
except:
pass)()

def init_db():
    '''Initialize database with all tables'''
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS users (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            username TEXT UNIQUE NOT NULL,\n            email TEXT UNIQUE NOT NULL,\n            password_hash TEXT NOT NULL,\n            is_admin INTEGER DEFAULT 0,\n            is_main_admin INTEGER DEFAULT 0,\n            created_at TEXT NOT NULL,\n            last_login TEXT,\n            last_active TEXT,\n            api_key TEXT UNIQUE,\n            profile_picture TEXT,\n            preferences TEXT DEFAULT '{}',\n            two_factor_secret TEXT,\n            two_factor_enabled INTEGER DEFAULT 0,\n            theme TEXT DEFAULT 'default',\n            language TEXT DEFAULT 'en'\n        )")
        cur.execute('CREATE INDEX IF NOT EXISTS idx_users_api_key ON users(api_key)')
        cur.execute('CREATE TABLE IF NOT EXISTS notifications (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            type TEXT NOT NULL,\n            title TEXT NOT NULL,\n            message TEXT NOT NULL,\n            read INTEGER DEFAULT 0,\n            created_at TEXT NOT NULL,\n            expires_at TEXT,\n            data TEXT,\n            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE\n        )')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read)')
        cur.execute("CREATE TABLE IF NOT EXISTS nodes (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            name TEXT UNIQUE NOT NULL,\n            location TEXT,\n            total_vps INTEGER DEFAULT 50,\n            used_vps INTEGER DEFAULT 0,\n            tags TEXT DEFAULT '[]',\n            api_key TEXT UNIQUE,\n            api_key_last_used TEXT,\n            url TEXT,\n            is_local INTEGER DEFAULT 0,\n            verify_ssl INTEGER DEFAULT 1,\n            ip_addresses TEXT DEFAULT '[]',\n            ip_aliases TEXT DEFAULT '[]',\n            status TEXT DEFAULT 'unknown',\n            last_seen TEXT,\n            cpu_cores INTEGER DEFAULT 0,\n            ram_total INTEGER DEFAULT 0,\n            disk_total INTEGER DEFAULT 0,\n            created_at TEXT NOT NULL,\n            updated_at TEXT NOT NULL\n        )")
        cur.execute('SELECT COUNT(*) FROM nodes WHERE is_local = 1')
        if cur.fetchone()[0] == 0:
            cur.execute('INSERT INTO nodes \n                (name, location, total_vps, tags, api_key, url, is_local, ip_addresses, created_at, updated_at) \n                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', ('Local Node', 'Local', 100, '[]', None, None, 1, json.dumps([
                YOUR_SERVER_IP]), datetime.now().isoformat(), datetime.now().isoformat()))
        cur.execute("CREATE TABLE IF NOT EXISTS vps (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            node_id INTEGER NOT NULL DEFAULT 1,\n            container_name TEXT UNIQUE NOT NULL,\n            hostname TEXT,\n            ram TEXT NOT NULL,\n            cpu TEXT NOT NULL,\n            storage TEXT NOT NULL,\n            config TEXT NOT NULL,\n            os_version TEXT DEFAULT 'ubuntu:22.04',\n            status TEXT DEFAULT 'stopped',\n            suspended INTEGER DEFAULT 0,\n            suspended_reason TEXT,\n            whitelisted INTEGER DEFAULT 0,\n            created_at TEXT NOT NULL,\n            updated_at TEXT NOT NULL,\n            last_started TEXT,\n            last_stopped TEXT,\n            backup_schedule TEXT,\n            backup_count INTEGER DEFAULT 0,\n            ip_address TEXT,\n            ip_alias TEXT,\n            shared_with TEXT DEFAULT '[]',\n            suspension_history TEXT DEFAULT '[]',\n            notes TEXT,\n            metadata TEXT DEFAULT '{}',\n            expires_at TEXT,\n            expiration_days INTEGER DEFAULT 0,\n            auto_suspend_enabled INTEGER DEFAULT 0,\n            last_renewed_at TEXT,\n            renewal_count INTEGER DEFAULT 0,\n            root_password TEXT DEFAULT 'root',\n            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,\n            FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE RESTRICT\n        )")
    with None:
        if not :
            pass

    
    try:
        cur.execute('SELECT root_password FROM vps LIMIT 1')
    except sqlite3.OperationalError:
        cur.execute("ALTER TABLE vps ADD COLUMN root_password TEXT DEFAULT 'root'")
        logger.info('Added root_password column to vps table')

    cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_user_id ON vps(user_id)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_node_id ON vps(node_id)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_status ON vps(status)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_suspended ON vps(suspended)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_expires_at ON vps(expires_at)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_auto_suspend ON vps(auto_suspend_enabled)')
    cur.execute('CREATE TABLE IF NOT EXISTS settings (\n            key TEXT PRIMARY KEY,\n            value TEXT NOT NULL,\n            description TEXT,\n            updated_at TEXT NOT NULL\n        )')
    settings_init = [
        ('cpu_threshold', '90', 'CPU usage threshold for auto-suspension (%)'),
        ('ram_threshold', '90', 'RAM usage threshold for auto-suspension (%)'),
        ('site_name', 'SVM PANEL', 'Site name'),
        ('site_description', 'High-Performance VPS Management Panel', 'Site description'),
        ('header_icon', '/static/img/logo.png', 'Header icon path'),
        ('favicon', '/static/img/favicon.ico', 'Favicon path'),
        ('footer_text', 'Powered by Svm Panel', 'Footer text'),
        ('maintenance_mode', '0', 'Maintenance mode (1=enabled, 0=disabled)'),
        ('maintenance_message', 'Site is under maintenance. Please check back later.', 'Maintenance message'),
        ('registration_enabled', '1', 'Registration enabled (1=enabled, 0=disabled)'),
        ('default_port_quota', '5', 'Default port quota for new users'),
        ('max_vps_per_user', '10', 'Maximum VPS per user'),
        ('session_timeout', '86400', 'Session timeout in seconds'),
        ('backup_enabled', '1', 'Auto backup enabled'),
        ('backup_retention', '7', 'Number of backups to retain'),
        ('smtp_host', '', 'SMTP host'),
        ('smtp_port', '587', 'SMTP port'),
        ('smtp_user', '', 'SMTP username'),
        ('smtp_pass', '', 'SMTP password'),
        ('smtp_from', '', 'SMTP from email'),
        ('theme', 'default', 'Default theme'),
        ('language', 'en', 'Default language'),
        ('timezone', 'UTC', 'Default timezone')]
    for key, value, description in settings_init:
        cur.execute('INSERT OR IGNORE INTO settings (key, value, description, updated_at) VALUES (?, ?, ?, ?)', (key, value, description, datetime.now().isoformat()))
    cur.execute('CREATE TABLE IF NOT EXISTS port_allocations (\n            user_id INTEGER PRIMARY KEY,\n            allocated_ports INTEGER DEFAULT 0,\n            used_ports INTEGER DEFAULT 0,\n            updated_at TEXT NOT NULL,\n            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE\n        )')
    cur.execute("CREATE TABLE IF NOT EXISTS port_forwards (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            vps_container TEXT NOT NULL,\n            vps_port INTEGER NOT NULL,\n            host_port INTEGER NOT NULL,\n            protocol TEXT DEFAULT 'tcp,udp',\n            description TEXT,\n            created_at TEXT NOT NULL,\n            last_used TEXT,\n            hits INTEGER DEFAULT 0,\n            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,\n            FOREIGN KEY(vps_container) REFERENCES vps(container_name) ON DELETE CASCADE\n        )")
    cur.execute('CREATE INDEX IF NOT EXISTS idx_port_forwards_user_id ON port_forwards(user_id)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_port_forwards_vps_container ON port_forwards(vps_container)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_port_forwards_host_port ON port_forwards(host_port)')
    cur.execute('CREATE TABLE IF NOT EXISTS sessions (\n            id TEXT PRIMARY KEY,\n            user_id INTEGER NOT NULL,\n            expires TEXT NOT NULL,\n            data TEXT,\n            ip_address TEXT,\n            user_agent TEXT,\n            created_at TEXT NOT NULL,\n            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE\n        )')
    cur.execute('CREATE TABLE IF NOT EXISTS activity_logs (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER,\n            action TEXT NOT NULL,\n            resource_type TEXT,\n            resource_id TEXT,\n            details TEXT,\n            ip_address TEXT,\n            user_agent TEXT,\n            created_at TEXT NOT NULL,\n            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL\n        )')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON activity_logs(user_id)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON activity_logs(created_at)')
    cur.execute('CREATE TABLE IF NOT EXISTS license (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            license_key TEXT NOT NULL,\n            activated INTEGER DEFAULT 0,\n            activated_at TEXT,\n            activated_by TEXT,\n            machine_id TEXT,\n            expires_at TEXT,\n            created_at TEXT NOT NULL\n        )')
    cur.execute('SELECT COUNT(*) FROM license')
    if cur.fetchone()[0] == 0:
        cur.execute('INSERT INTO license \n                (license_key, activated, created_at) \n                VALUES (?, ?, ?)', ('', 0, datetime.now().isoformat()))
    cur.execute("CREATE TABLE IF NOT EXISTS backups (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            vps_id INTEGER NOT NULL,\n            name TEXT NOT NULL,\n            size INTEGER DEFAULT 0,\n            path TEXT NOT NULL,\n            created_at TEXT NOT NULL,\n            expires_at TEXT,\n            status TEXT DEFAULT 'completed',\n            FOREIGN KEY(vps_id) REFERENCES vps(id) ON DELETE CASCADE\n        )")
    cur.execute('CREATE TABLE IF NOT EXISTS os_icons (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            os_name TEXT UNIQUE NOT NULL,\n            icon_path TEXT NOT NULL,\n            uploaded_at TEXT NOT NULL,\n            uploaded_by INTEGER,\n            FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE SET NULL\n        )')
    cur.execute("CREATE TABLE IF NOT EXISTS api_keys (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            key TEXT UNIQUE NOT NULL,\n            name TEXT NOT NULL,\n            description TEXT,\n            is_active INTEGER DEFAULT 1,\n            created_at TEXT NOT NULL,\n            last_used_at TEXT,\n            expires_at TEXT,\n            permissions TEXT DEFAULT '[]',\n            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE\n        )")
    cur.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_user_id ON api_keys(user_id)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(key)')
    cur.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_active ON api_keys(is_active)')
    cur.execute('SELECT COUNT(*) FROM users WHERE is_main_admin = 1')
    if cur.fetchone()[0] == 0:
        password_hash = generate_password_hash(MAIN_ADMIN_PASSWORD)
        api_key = generate_api_key(64)
        now = datetime.now().isoformat()
        cur.execute('INSERT INTO users \n                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, api_key, preferences)\n                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', (MAIN_ADMIN_USERNAME, MAIN_ADMIN_EMAIL, password_hash, 1, 1, now, now, api_key, '{}'))
        cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, updated_at) VALUES (?, ?, ?)', (cur.lastrowid, 100, now))
    conn.commit()
    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS users (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            username TEXT UNIQUE NOT NULL,\n            email TEXT UNIQUE NOT NULL,\n            password_hash TEXT NOT NULL,\n            is_admin INTEGER DEFAULT 0,\n            is_main_admin INTEGER DEFAULT 0,\n            created_at TEXT NOT NULL,\n            last_login TEXT,\n            last_active TEXT,\n            api_key TEXT UNIQUE,\n            profile_picture TEXT,\n            preferences TEXT DEFAULT '{}',\n            two_factor_secret TEXT,\n            two_factor_enabled INTEGER DEFAULT 0,\n            theme TEXT DEFAULT 'default',\n            language TEXT DEFAULT 'en'\n        )")
        cur.execute('CREATE INDEX IF NOT EXISTS idx_users_api_key ON users(api_key)')
        cur.execute('CREATE TABLE IF NOT EXISTS notifications (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            type TEXT NOT NULL,\n            title TEXT NOT NULL,\n            message TEXT NOT NULL,\n            read INTEGER DEFAULT 0,\n            created_at TEXT NOT NULL,\n            expires_at TEXT,\n            data TEXT,\n            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE\n        )')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read)')
        cur.execute("CREATE TABLE IF NOT EXISTS nodes (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            name TEXT UNIQUE NOT NULL,\n            location TEXT,\n            total_vps INTEGER DEFAULT 50,\n            used_vps INTEGER DEFAULT 0,\n            tags TEXT DEFAULT '[]',\n            api_key TEXT UNIQUE,\n            api_key_last_used TEXT,\n            url TEXT,\n            is_local INTEGER DEFAULT 0,\n            verify_ssl INTEGER DEFAULT 1,\n            ip_addresses TEXT DEFAULT '[]',\n            ip_aliases TEXT DEFAULT '[]',\n            status TEXT DEFAULT 'unknown',\n            last_seen TEXT,\n            cpu_cores INTEGER DEFAULT 0,\n            ram_total INTEGER DEFAULT 0,\n            disk_total INTEGER DEFAULT 0,\n            created_at TEXT NOT NULL,\n            updated_at TEXT NOT NULL\n        )")
        cur.execute('SELECT COUNT(*) FROM nodes WHERE is_local = 1')
        if cur.fetchone()[0] == 0:
            cur.execute('INSERT INTO nodes \n                (name, location, total_vps, tags, api_key, url, is_local, ip_addresses, created_at, updated_at) \n                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', ('Local Node', 'Local', 100, '[]', None, None, 1, json.dumps([
                YOUR_SERVER_IP]), datetime.now().isoformat(), datetime.now().isoformat()))
        cur.execute("CREATE TABLE IF NOT EXISTS vps (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            user_id INTEGER NOT NULL,\n            node_id INTEGER NOT NULL DEFAULT 1,\n            container_name TEXT UNIQUE NOT NULL,\n            hostname TEXT,\n            ram TEXT NOT NULL,\n            cpu TEXT NOT NULL,\n            storage TEXT NOT NULL,\n            config TEXT NOT NULL,\n            os_version TEXT DEFAULT 'ubuntu:22.04',\n            status TEXT DEFAULT 'stopped',\n            suspended INTEGER DEFAULT 0,\n            suspended_reason TEXT,\n            whitelisted INTEGER DEFAULT 0,\n            created_at TEXT NOT NULL,\n            updated_at TEXT NOT NULL,\n            last_started TEXT,\n            last_stopped TEXT,\n            backup_schedule TEXT,\n            backup_count INTEGER DEFAULT 0,\n            ip_address TEXT,\n            ip_alias TEXT,\n            shared_with TEXT DEFAULT '[]',\n            suspension_history TEXT DEFAULT '[]',\n            notes TEXT,\n            metadata TEXT DEFAULT '{}',\n            expires_at TEXT,\n            expiration_days INTEGER DEFAULT 0,\n            auto_suspend_enabled INTEGER DEFAULT 0,\n            last_renewed_at TEXT,\n            renewal_count INTEGER DEFAULT 0,\n            root_password TEXT DEFAULT 'root',\n            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,\n            FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE RESTRICT\n        )")
    with None:
        if not :
            pass

    except:
        pass


def migrate_discord_auth():
    '''Add Discord authentication fields to users table'''
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('PRAGMA table_info(users)')
    with None:
        if not :
            pass

    for None in :
        pass
    get_db(), [], columns = None
    column = None
    if 'discord_id' not in columns:
        
        try:
            cur.execute('ALTER TABLE users ADD COLUMN discord_id TEXT')
            cur.execute('ALTER TABLE users ADD COLUMN discord_username TEXT')
            cur.execute('ALTER TABLE users ADD COLUMN discord_avatar TEXT')
            cur.execute('ALTER TABLE users ADD COLUMN discord_email TEXT')
            cur.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_discord_id ON users(discord_id) WHERE discord_id IS NOT NULL')
            conn.commit()
            logger.info('Discord authentication fields added to users table')
        except Exception:
            column, e = None, None, None
            logger.error(f'''Error adding Discord fields: {e}''')

        discord_settings = {
            'discord_auth_enabled': '0',
            'discord_client_id': '',
            'discord_client_secret': '',
            'discord_redirect_uri': 'http://localhost:5000/auth/discord/callback',
            'discord_auto_register': '1',
            'discord_button_text': 'Continue with Discord' }
        for key, default_value in discord_settings.items():
            cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
            if cur.fetchone():
                continue
            cur.execute('INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?)', (key, default_value, datetime.now().isoformat()))
        conn.commit()
        None(None, None)
        return None
        
        
        try:
            conn = get_db()
            cur = conn.cursor()
            cur.execute('PRAGMA table_info(users)')
        with None:
            if not :
                pass

    except:
        pass
    column, e
    None, None, None


def generate_api_key(length = 64):
    return secrets.token_urlsafe(length)


def get_setting(key, default = None):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
        row = cur.fetchone()

    None(None, None)
    return 
    with None:
        if not None, row[0] if row else default:
            pass


def set_setting(key, value):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)', (key, value, datetime.now().isoformat()))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)', (key, value, datetime.now().isoformat()))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass


def log_activity(user_id, action, resource_type = None, resource_id = None, details = None):
    
    try:
        pass
    except Exception:
        e = None
        logger.error(f'''Failed to log activity: {e}''')

    
    try:
        conn = None
        cur = conn.cursor()
        cur.execute('INSERT INTO activity_logs \n                (user_id, action, resource_type, resource_id, details, ip_address, user_agent, created_at)\n                VALUES (?, ?, ?, ?, ?, ?, ?, ?)', (user_id, action, resource_type, resource_id, json.dumps(details) if details else None, request.remote_addr if request else None, request.user_agent.string if request and hasattr(request, 'user_agent') else None, datetime.now().isoformat()))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = None
        cur = conn.cursor()
        cur.execute('INSERT INTO activity_logs \n                (user_id, action, resource_type, resource_id, details, ip_address, user_agent, created_at)\n                VALUES (?, ?, ?, ?, ?, ?, ?, ?)', (user_id, action, resource_type, resource_id, json.dumps(details) if details else None, request.remote_addr if request else None, request.user_agent.string if request and hasattr(request, 'user_agent') else None, datetime.now().isoformat()))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass


def create_notification(user_id, type, title, message, data = None, expires_in = None):
    
    try:
        expires_at = None
        if expires_in:
            expires_at = (datetime.now() + timedelta(seconds = expires_in)).isoformat()
    except Exception:
        e = None
        logger.error(f'''Failed to create notification: {e}''')

    
    try:
        conn = None
        cur = conn.cursor()
        cur.execute('INSERT INTO notifications \n                (user_id, type, title, message, created_at, expires_at, data)\n                VALUES (?, ?, ?, ?, ?, ?, ?)', (user_id, type, title, message, datetime.now().isoformat(), expires_at, json.dumps(data) if data else None))
        conn.commit()
        if socketio:
            socketio.emit('new_notification', {
                'id': cur.lastrowid,
                'type': type,
                'title': title,
                'message': message,
                'created_at': datetime.now().isoformat() }, room = f'''user_{user_id}''')

    None(None, None)
    return None
    with None:
        if not None:
            pass


def get_user_notifications(user_id, unread_only = False, limit = 50):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        query = 'SELECT * FROM notifications WHERE user_id = ?'
        params = [
            user_id]
        if unread_only:
            query += ' AND read = 0'
        query += ' AND (expires_at IS NULL OR expires_at > ?)'
        params.append(datetime.now().isoformat())
        query += ' ORDER BY created_at DESC LIMIT ?'
        params.append(limit)
        cur.execute(query, params)
    with None:
        if not :
            pass

    for None in :
        pass
    get_db(), [], notifications = None
    row = None
    for notif in notifications:
        if not notif['data']:
            continue
        
        try:
            notif['data'] = json.loads(notif['data'])
        except:
            { } = row,

    None(None, None)
    return 
    
    
    try:
        conn = get_db()
        cur = conn.cursor()
        query = 'SELECT * FROM notifications WHERE user_id = ?'
        params = [
            user_id]
        if unread_only:
            query += ' AND read = 0'
        query += ' AND (expires_at IS NULL OR expires_at > ?)'
        params.append(datetime.now().isoformat())
        query += ' ORDER BY created_at DESC LIMIT ?'
        params.append(limit)
        cur.execute(query, params)
    with None:
        if not :
            pass

    except:
        pass
    row,
    None, None, None, notifications


def mark_notification_read(notification_id, user_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?', (notification_id, user_id))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?', (notification_id, user_id))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass


def mark_all_notifications_read(user_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE notifications SET read = 1 WHERE user_id = ? AND read = 0', (user_id,))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE notifications SET read = 1 WHERE user_id = ? AND read = 0', (user_id,))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass


def get_unread_notifications_count(user_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM notifications \n                      WHERE user_id = ? AND read = 0 \n                      AND (expires_at IS NULL OR expires_at > ?)', (user_id, datetime.now().isoformat()))
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM notifications \n                      WHERE user_id = ? AND read = 0 \n                      AND (expires_at IS NULL OR expires_at > ?)', (user_id, datetime.now().isoformat()))
    with None:
        if not :
            pass

    except:
        pass


def is_license_activated():
    """Check if license is activated - ALWAYS TRUE (license key request removed by AnkitCoder)"""
    return True

def get_license_info():
    '''Get license information - Never expose the actual key'''
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT id, activated, activated_at, activated_by, machine_id, expires_at, created_at FROM license WHERE id = 1')
        row = cur.fetchone()
        if row:
            info = dict(row)
            None(None, None)
            return 
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT id, activated, activated_at, activated_by, machine_id, expires_at, created_at FROM license WHERE id = 1')
        row = cur.fetchone()
        if row:
            info = dict(row)
            None(None, None)
            return 
    with None:
        if not :
            pass

    except:
        pass


def activate_license(license_key, activated_by = 'system'):
    '''Activate license with the provided key - Multi-layer obfuscated validation'''
    
    try:
        _a = b'aHZtcGFuZWx2Nm1hZGVieWhvcGluZ2JveXpsb3ZlYXRhc2lyZWFsbHlpbG92ZXlvdWp1c3R0cnl0b3VuZGVyc3RhbmRtZQ=='
        _b = base64.b64decode(_a).decode()[::-1]
        _k = [
            72,
            86,
            77,
            80,
            65,
            78,
            69,
            76]
        _c = (lambda .0: if None:
passfor i in .0:
if chr(ord(_b[i]) ^ _k[i % len(_k)]):
passchr(ord(_b[i]) ^ _k[i % len(_k)]))(range(len(_b))())
        _d = _c[::-1]
        _e = (lambda .0: if None:
passfor c in .0:
if  <= 'a', c or 'a', c <= 'z':
passif c:
passccontinue)(_d())
        _f = base64.b64decode(b'aHZtcGFuZWx2Nm1hZGVieWhvcGluZ2JveXpsb3ZlYXRhc2lyZWFsbHlpbG92ZXlvdWp1c3R0cnl0b3VuZGVyc3RhbmRtZQ==').decode()
        input_hash = hashlib.sha256(license_key.strip().encode()).hexdigest()
        correct_hash = hashlib.sha256(_f.encode()).hexdigest()
        if hmac.compare_digest(input_hash, correct_hash):
            
            try:
                conn = get_db()
                cur = conn.cursor()
                machine_id = str(uuid.uuid4())
                cur.execute('UPDATE license SET \n                    license_key = ?,\n                    activated = 1,\n                    activated_at = ?,\n                    activated_by = ?,\n                    machine_id = ?\n                    WHERE id = 1', (input_hash, datetime.now().isoformat(), activated_by, machine_id))
                conn.commit()
                logger.info(f'''License activated by {activated_by}''')
            with None:
                if not :
                    pass

            None(None, None)
            return (True, 'License activated successfully!')

    logger.warning('Failed license activation attempt')
    return (False, 'Invalid license key. Please check and try again.')
    
    try:
        conn = get_db()
        cur = conn.cursor()
        machine_id = str(uuid.uuid4())
        cur.execute('UPDATE license SET \n                    license_key = ?,\n                    activated = 1,\n                    activated_at = ?,\n                    activated_by = ?,\n                    machine_id = ?\n                    WHERE id = 1', (input_hash, datetime.now().isoformat(), activated_by, machine_id))
        conn.commit()
        logger.info(f'''License activated by {activated_by}''')
    with None:
        if not :
            pass

    except:
        pass
    ''.join
    return None
    except Exception:
        e = None
        logger.error(f'''License validation error: {e}''')
    e = None
    del e
    return (False, 'License validation failed. Please contact support.')
    e = None
    del e

check_license = (lambda : None)()  # License check removed by AnkitCoder
check_maintenance_mode = (lambda : if request.endpoint in ('static', 'login', 'logout', 'register', 'health', 'favicon', 'serve_static'):
Noneif request.path.startswith('/api/'):
Nonemaintenance_mode = get_setting('maintenance_mode', '0') == '1'if maintenance_mode:
if current_user.is_authenticated and current_user.is_admin:
None(render_template('maintenance.html', message = get_setting('maintenance_message', 'Site is under maintenance. Please check back later.'), panel_name = get_setting('site_name', 'SVM PANEL')), 503))()
after_request = (lambda response: try:
if not response.content_type:
response.content_type = 'text/html; charset=utf-8'response.headers['X-Content-Type-Options'] = 'nosniff'response.headers['X-Frame-Options'] = 'SAMEORIGIN'response.headers['X-XSS-Protection'] = '1; mode=block'except Exception:
e = Nonelogger.error(f'''Error in after_request: {e}'''))()

class User(UserMixin):
    
    def __init__(self, user_data):
        self.id = user_data['id']
        self.username = user_data['username']
        self.email = user_data['email']
        self.password_hash = user_data['password_hash']
        self.is_admin = bool(user_data['is_admin'])
        self.is_main_admin = bool(user_data['is_main_admin'])
        self.created_at = user_data['created_at']
        self.last_login = user_data.get('last_login')
        self.last_active = user_data.get('last_active')
        self.api_key = user_data.get('api_key')
        self.profile_picture = user_data.get('profile_picture')
        
        try:
            self.preferences = json.loads(user_data.get('preferences', '{}'))
        except:
            self.preferences = { }

        self.two_factor_enabled = bool(user_data.get('two_factor_enabled', 0))
        self.theme = user_data.get('theme', 'default')
        self.language = user_data.get('language', 'en')
        self.discord_id = user_data.get('discord_id')
        self.discord_username = user_data.get('discord_username')
        self.discord_avatar = user_data.get('discord_avatar')
        self.discord_email = user_data.get('discord_email')

    get = (lambda user_id: try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))user_data = cur.fetchone()if user_data:
None(None, None)with None:
if not :
passNone(None, None)Nonetry:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))user_data = cur.fetchone()if user_data:
None(None, None)with None:
if not :
passexcept:
pass)()
    get_by_username = (lambda username: try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE username = ?', (username,))user_data = cur.fetchone()if user_data:
None(None, None)with None:
if not :
passNone(None, None)Nonetry:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE username = ?', (username,))user_data = cur.fetchone()if user_data:
None(None, None)with None:
if not :
passexcept:
pass)()
    get_by_email = (lambda email: try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE email = ?', (email,))user_data = cur.fetchone()if user_data:
None(None, None)with None:
if not :
passNone(None, None)Nonetry:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE email = ?', (email,))user_data = cur.fetchone()if user_data:
None(None, None)with None:
if not :
passexcept:
pass)()
    get_by_api_key = (lambda api_key: try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE api_key = ?', (api_key,))user_data = cur.fetchone()if user_data:
cur.execute('UPDATE users SET last_active = ? WHERE id = ?', (datetime.now().isoformat(), user_data['id']))conn.commit()None(None, None)with None:
if not :
passNone(None, None)Nonetry:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE api_key = ?', (api_key,))user_data = cur.fetchone()if user_data:
cur.execute('UPDATE users SET last_active = ? WHERE id = ?', (datetime.now().isoformat(), user_data['id']))conn.commit()None(None, None)with None:
if not :
passexcept:
pass)()

load_user = (lambda user_id: User.get(int(user_id)))()

def admin_required(f):
    decorated_function = (lambda : if not current_user.is_authenticated or current_user.is_admin:
if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
(jsonify({
'success': False,
'error': 'Admin access required' }), 403)None('Admin access required.', 'danger')redirect(url_for('dashboard'))args({ }, kwargs = None))()
    return decorated_function


def main_admin_required(f):
    decorated_function = (lambda : if not current_user.is_authenticated or current_user.is_main_admin:
if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
(jsonify({
'success': False,
'error': 'Main admin access required' }), 403)None('Main admin access required.', 'danger')redirect(url_for('dashboard'))args({ }, kwargs = None))()
    return decorated_function


def api_key_required(f):
    decorated_function = (lambda : if not request.headers.get('X-API-Key'):
request.headers.get('X-API-Key')api_key = request.args.get('api_key')if not api_key:
(jsonify({
'error': 'API key required' }), 401)user = None.get_by_api_key(api_key)if not user:
(jsonify({
'error': 'Invalid API key' }), 401)request.api_user = Noneargs({ }, kwargs = None))()
    return decorated_function


def vps_owner_or_admin_required(f):
    decorated_function = (lambda vps_id: vps = get_vps_by_id(vps_id)if not vps:
flash('VPS not found', 'danger')redirect(url_for('vps_list'))if not None['user_id'] != current_user.id and current_user.is_admin:
shared_with = vps.get('shared_with', [])for None in :
passif str(current_user.id), shared_with, , [] not in uid,:
flash('Access denied', 'danger')redirect(url_for('vps_list'))None(f)({ }, kwargs = None))()
    return decorated_function

app.jinja_env.globals.update(get_setting = get_setting)
app.jinja_env.globals.update(now = datetime.now)
app.jinja_env.globals.update(get_unread_notifications_count = get_unread_notifications_count)
if socketio:
    handle_connect = (lambda : if current_user.is_authenticated:
join_room(f'''user_{current_user.id}''')emit('connected', {
'status': 'connected',
'user_id': current_user.id })count = get_unread_notifications_count(current_user.id)emit('unread_count', {
'count': count })None)()
    handle_disconnect = (lambda : if current_user.is_authenticated:
leave_room(f'''user_{current_user.id}''')try:
active_consoles_lockto_remove = []for vps_id, info in active_consoles.items():
if not info.get('sid') == request.sid:
continueto_remove.append(vps_id)try:
if 'proc' in info and info['proc']:
info['proc'].terminate()continuefor vps_id in to_remove:
active_consoles.pop(vps_id, None)None(None, None)Nonecontinuewith None:
if not None:
pass)()
    handle_join_vps_room = (lambda data: vps_id = data.get('vps_id')if current_user.is_authenticated:
if vps_id:
room = f'''vps_{vps_id}'''join_room(room)emit('joined_vps_room', {
'vps_id': vps_id,
'room': room })NoneNone)()
    handle_leave_vps_room = (lambda data: vps_id = data.get('vps_id')if vps_id:
leave_room(f'''vps_{vps_id}''')None)()
    handle_request_vps_stats = (lambda data: vps_id = data.get('vps_id')if not current_user.is_authenticated or vps_id:
Nonevps = get_vps_by_id(vps_id)if not (vps or vps['user_id'] != current_user.id) and current_user.is_admin:
Nonetry:
stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))emit('vps_stats', {
'vps_id': vps_id,
'stats': stats })except Exception:
e = Nonelogger.error(f'''Error getting VPS stats for socket: {e}'''))()
    handle_console_input = (lambda data: vps_id = data.get('vps_id')input_data = data.get('input', '')if not current_user.is_authenticated or vps_id:
Nonetry:
active_consoles_lockinfo = active_consoles.get(vps_id)if info or info.get('sid') != request.sid:
emit('console_output', b'Console not active or not owned by you\r\n')None(None, None)Noneproc = info.get('proc')if not proc:
None(None, None)Nonetry:
if isinstance(input_data, str):
input_data = input_data.encode('utf-8', errors = 'replace')proc.stdin.write(input_data)proc.stdin.flush()except (BrokenPipeError, OSError):
emit('console_output', b'[Connection lost]\r\n')active_consoles.pop(vps_id, None)continueexcept Exception:
e = Noneemit('console_output', f'''[Error: {e}]\r\n'''.encode('utf-8'))None(None, None)Nonewith None:
if not None:
pass)()
    handle_console_resize = (lambda data: vps_id = data.get('vps_id')cols = data.get('cols', 80)rows = data.get('rows', 24)try:
active_consoles_lockinfo = active_consoles.get(vps_id)if info and info.get('sid') == request.sid and 'proc' in info:
try:
import fcntlimport termiosimport structfcntl.ioctl(info['proc'].stdout.fileno(), termios.TIOCSWINSZ, struct.pack('HHHH', rows, cols, 0, 0))except:
passNone(None, None)Nonewith None:
if not None:
pass)()

async def execute_lxc(container_name, command, timeout = 120, node_id = None):
    if None:
        pass
    if node_id and container_name:
        node_id = find_node_id_for_container(container_name)
    node = get_node(node_id)
    if not node:
        raise Exception(f'''Node {node_id} not found''')
    full_command = f'''lxc {command}'''
    if node['is_local']:
        
        try:
            logger.debug(f'''Executing local command: {full_command}''')
            cmd = shlex.split(full_command)
            if None or None:
                continue

        proc = None
        
        try:
            if None or None:
                continue

        (stdout, stderr) = None
        stdout_str = stdout.decode().strip() if stdout else ''
        stderr_str = stderr.decode().strip() if stderr else ''
        if proc.returncode != 0:
            error = stderr_str if stderr_str else f'''Command failed with return code {proc.returncode}'''
            raise Exception(f'''Local LXC command failed: {error}\nCommand: {full_command}''')
        if stdout_str:
            return stdout_str
        return asyncio.wait_for(proc.communicate(), timeout = timeout)
    
    try:
        import requests
        url = f'''{node['url']}/api/execute'''
        data = {
            'command': full_command,
            'timeout': timeout }
        headers = {
            'X-API-Key': node['api_key'] }
        verify_ssl = bool(node.get('verify_ssl', 1))
    except requests.exceptions.RequestException:
        e = None
        logger.error(f'''Remote LXC error on node {node['name']} ({url}): {str(e)}''')
        
        try:
            conn = get_db()
            cur = conn.cursor()
            cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?', ('offline', datetime.now().isoformat(), node_id))
            conn.commit()
        with None:
            if not :
                pass

        None(None, None)
    except:
        
        try:
            conn = get_db()
            cur = conn.cursor()
            cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?', ('offline', datetime.now().isoformat(), node_id))
            conn.commit()
        with None:
            if not :
                pass

        except:
            pass
        get_db()
    except:
        pass
    if hasattr(e, 'response') and hasattr(e.response, 'status_code'):
        raise Exception(f'''Remote execution failed on {node['name']}: HTTP {e.response.status_code} - {str(e)}''')
    raise Exception(f'''Remote execution failed on {node['name']}: {str(e)}''')
    e = None
    del e

    
    try:
        conn = node_id
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET api_key_last_used = ? WHERE id = ?', (datetime.now().isoformat(), node_id))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    response = requests.post(url, json = data, headers = headers, timeout = timeout + 5, verify = verify_ssl)
    response.raise_for_status()
    res = response.json()
    if not res.get('success', False):
        stderr = res.get('stderr', 'Command failed')
        raise Exception(f'''Remote LXC command failed on {node['name']}: {stderr}\nCommand: {full_command}''')
    return res.get('stdout', True)
    continue
    continue
    if asyncio.TimeoutError:
        node_id
        proc.kill()
        if None or None:
            continue
        raise asyncio.TimeoutError(f'''Command timed out after {timeout} seconds''')
    if asyncio.TimeoutError:
        te = None
        logger.error(f'''LXC command timed out: {full_command} - {str(te)}''')
        raise 
    te = None
    del te
    if Exception:
        e = None
        logger.error(f'''LXC Error: {full_command} - {str(e)}''')
        raise 
    e = None
    del e
    
    try:
        conn = node_id
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET api_key_last_used = ? WHERE id = ?', (datetime.now().isoformat(), node_id))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass
    node_id
    continue
    
    try:
        import requests
        url = f'''{node['url']}/api/execute'''
        data = {
            'command': full_command,
            'timeout': timeout }
        headers = {
            'X-API-Key': node['api_key'] }
        verify_ssl = bool(node.get('verify_ssl', 1))
    except requests.exceptions.RequestException:
        e = None
        logger.error(f'''Remote LXC error on node {node['name']} ({url}): {str(e)}''')
        
        try:
            conn = get_db()
            cur = conn.cursor()
            cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?', ('offline', datetime.now().isoformat(), node_id))
            conn.commit()
        with None:
            if not :
                pass

        None(None, None)
    except:
        
        try:
            conn = get_db()
            cur = conn.cursor()
            cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?', ('offline', datetime.now().isoformat(), node_id))
            conn.commit()
        with None:
            if not :
                pass

        except:
            pass
        get_db()
    except:
        pass
    if hasattr(e, 'response') and hasattr(e.response, 'status_code'):
        raise Exception(f'''Remote execution failed on {node['name']}: HTTP {e.response.status_code} - {str(e)}''')
    raise Exception(f'''Remote execution failed on {node['name']}: {str(e)}''')
    e = None
    del e



def run_sync(coro):
    
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        pass

    if loop and loop.is_running():
        import concurrent.futures as concurrent
        
        try:
            executor = concurrent.futures.ThreadPoolExecutor()
            future = executor.submit(asyncio.run, coro)
        with None:
            if not :
                pass

        None(None, None)
        return 
    return None.run(coro)
    
    try:
        executor = concurrent.futures.ThreadPoolExecutor()
        future = executor.submit(asyncio.run, coro)
    with None:
        if not :
            pass

    except:
        pass


async def container_action_remote(node, container_name, action, timeout = 60):
    '''
    Perform container action on remote node using dedicated API endpoints
    Actions: start, stop, restart
    '''
    if None:
        pass
    
    try:
        import requests
        url = f'''{node['url']}/api/container/{action}'''
        data = {
            'container': container_name,
            'timeout': timeout }
        headers = {
            'X-API-Key': node['api_key'] }
        verify_ssl = bool(node.get('verify_ssl', 1))
        response = requests.post(url, json = data, headers = headers, timeout = timeout + 5, verify = verify_ssl)
        response.raise_for_status()
        result = response.json()
        if result.get('success', False):
            logger.info(f'''Container {action} successful on remote node {node['name']}: {container_name}''')
            return True

    error = result.get('error', 'Unknown error')
    logger.error(f'''Container {action} failed on remote node {node['name']}: {error}''')
    return False
    if Exception:
        e = None
        logger.error(f'''Failed to {action} container {container_name} on remote node {node['name']}: {e}''')
        e = None
        del e
        return False
        e = None
        del e


async def apply_lxc_config(container_name, node_id):
    if None:
        pass
    
    try:
        if None or None:
            continue

    if None or None:
        continue
    if None or None:
        continue
    if None or None:
        continue
    if None or None:
        continue
    
    try:
        if None or None:
            continue

    raw_lxc_config = 'lxc.apparmor.profile = unconfined\nlxc.apparmor.allow_nesting = 1\nlxc.apparmor.allow_incomplete = 1\n\nlxc.cap.drop =\nlxc.cgroup.devices.allow = a\nlxc.cgroup2.devices.allow = a\n\nlxc.mount.auto = proc:rw sys:rw cgroup:rw shmounts:rw\n\nlxc.mount.entry = /dev/fuse dev/fuse none bind,create=file 0 0\n'
    if None or None:
        continue
    logger.info(f'''LXC permissions applied to {container_name} on node {node_id}''')
    return None
    continue
    continue
    continue
    continue
    continue
    continue
    if Exception:
        e = execute_lxc(container_name, f'''config set {container_name} raw.lxc \'{raw_lxc_config}\'''', node_id = node_id)
        logger.warning(f'''Could not add fuse device for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    continue
    if Exception:
        e = execute_lxc(container_name, f'''config set {container_name} security.syscalls.intercept.setxattr true''', node_id = node_id)
        logger.error(f'''Failed to apply LXC config to {container_name}: {e}''')
        raise 
    e = None
    del e


async def configure_container_ip(container_name, ip_address, node_id):
    '''Configure static IP address for LXC container using network device'''
    if None:
        pass
    
    try:
        if None or None:
            continue

    
    try:
        if None or None:
            continue

    logger.info(f'''Configured IP {ip_address} on {container_name}''')
    
    try:
        if None or None:
            continue

    if None or None:
        continue
    if None or None:
        continue
    logger.info(f'''Configured IP {ip_address} inside {container_name}''')
    return None
    continue
    execute_lxc(container_name, f'''exec {container_name} -- ip link set eth0 up''', node_id = node_id)
    if None or None:
        continue
    logger.info(f'''Added eth0 network device to {container_name}''')
    continue
    continue
    continue
    continue
    continue
    if Exception:
        e = asyncio.sleep(2)
        logger.warning(f'''Could not configure IP inside container {container_name}: {e}''')
        e = None
        del e
        return None
        e = None
        del e
    if Exception:
        e = asyncio.sleep(2)
        logger.error(f'''Failed to configure IP for {container_name}: {e}''')
        raise 
    e = None
    del e


async def apply_internal_permissions(container_name, node_id):
    if None:
        pass
    
    try:
        if None or None:
            continue

    
    try:
        if None or None:
            continue
            os_check = None

    for cmd in commands:
        
        try:
            if None or None:
                continue

    continue
    logger.info(f'''Internal permissions applied to {container_name}''')
    return None
    continue
    continue
    is_alpine = False
    continue
    continue
    if Exception:
        cmd_error = None
        logger.warning(f'''Command failed in {container_name}: {cmd} - {cmd_error}''')
        cmd_error = None
        del cmd_error
        continue
        cmd_error = None
        del cmd_error
    if Exception:
        e = None
        logger.error(f'''Failed to apply internal permissions to {container_name}: {e}''')
        e = None
        del e
        return None
        e = None
        del e


async def configure_ssh_and_root_password(container_name, node_id):
    """Configure SSH settings and set root password to 'root'"""
    if None:
        pass
    
    try:
        if None or None:
            continue

    
    try:
        if None or None:
            continue
            os_check = None

    if 'alpine' in os_check.lower():
        if None or None:
            continue
        elif None or None:
            continue
    ssh_config = '# SSH LOGIN SETTINGS\nPasswordAuthentication yes\nPermitRootLogin yes\nPubkeyAuthentication no\nChallengeResponseAuthentication no\nUsePAM yes\n\n# SFTP SETTINGS\nSubsystem sftp /usr/lib/openssh/sftp-server'
    ssh_config_cmd = f'''cat <<\'EOF\' > /etc/ssh/sshd_config\n{ssh_config}\nEOF'''
    if None or None:
        continue
    logger.info(f'''SSH config written for {container_name}''')
    
    try:
        if None or None:
            continue

    logger.info(f'''SSH service restarted for {container_name}''')
    
    try:
        if None or None:
            continue

    logger.info(f'''Root password set for {container_name}''')
    logger.info(f'''SSH and root password configured for {container_name}''')
    return None
    continue
    continue
    continue
    continue
    if Exception:
        e = execute_lxc(container_name, f'''exec {container_name} -- sh -c "echo \'root:root\' | chpasswd"''', node_id = node_id)
        logger.warning(f'''Could not install SSH server in {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    continue
    continue
    execute_lxc(container_name, f'''exec {container_name} -- apt-get install -y openssh-server''', node_id = node_id)
    
    try:
        if None or None:
            continue
        else:
            
            try:
                if None or None:
                    continue
                elif Exception:
                    e = execute_lxc(container_name, f'''exec {container_name} -- /etc/init.d/sshd restart''', node_id = node_id)
                    logger.warning(f'''Could not restart SSH in {container_name}: {e}''')
                    e = None
                    del e
                else:
                    e = None
                    del e

    except:
        continue
        continue
        if Exception:
            e = execute_lxc(container_name, f'''exec {container_name} -- apt-get install -y openssh-server''', node_id = node_id)
            logger.error(f'''Failed to set root password for {container_name}: {e}''')
            e = None
            del e
            continue
            e = None
            del e

    if Exception:
        e = execute_lxc(container_name, f'''exec {container_name} -- apt-get install -y openssh-server''', node_id = node_id)
        logger.error(f'''Failed to configure SSH for {container_name}: {e}''')
        e = None
        del e
        return None
        e = None
        del e


def get_nodes():
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes ORDER BY name')
        rows = cur.fetchall()
        nodes = []
        for row in rows:
            node = dict(row)
            
            try:
                node['tags'] = json.loads(node['tags']) if node['tags'] else []
            except:
                pass

            
            try:
                node['ip_addresses'] = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            except:
                [] = None

            
            try:
                node['ip_aliases'] = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            except:
                node['ip_aliases'] = []

            nodes.append(node)
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes ORDER BY name')
        rows = cur.fetchall()
        nodes = []
        for row in rows:
            node = dict(row)
            
            try:
                node['tags'] = json.loads(node['tags']) if node['tags'] else []
            except:
                pass

            
            try:
                node['ip_addresses'] = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            except:
                [] = None

            
            try:
                node['ip_aliases'] = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            except:
                node['ip_aliases'] = []

            nodes.append(node)
    with None:
        if not :
            pass

    except:
        pass


def get_node(node_id):
    if node_id:
        return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes WHERE id = ?', (node_id,))
        row = cur.fetchone()
        if row:
            node = dict(row)
            
            try:
                node['tags'] = json.loads(node['tags']) if node['tags'] else []
            except:
                pass

            
            try:
                node['ip_addresses'] = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            except:
                [] = None

            
            try:
                node['ip_aliases'] = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            except:
                node['ip_aliases'] = []

            None(None, None)
            return 
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes WHERE id = ?', (node_id,))
        row = cur.fetchone()
        if row:
            node = dict(row)
            
            try:
                node['tags'] = json.loads(node['tags']) if node['tags'] else []
            except:
                pass

            
            try:
                node['ip_addresses'] = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            except:
                [] = None

            
            try:
                node['ip_aliases'] = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            except:
                node['ip_aliases'] = []

            None(None, None)
            return 
    with None:
        if not :
            pass

    except:
        pass
    node_id


def update_node(node_id, **kwargs):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        fields = []
        values = []
        for key, value in kwargs.items():
            if key in ('tags', 'ip_addresses', 'ip_aliases') and isinstance(value, (list, dict)):
                value = json.dumps(value)
            fields.append(f'''{key} = ?''')
            values.append(value)
        values.append(node_id)
        values.append(datetime.now().isoformat())
        cur.execute(f'''UPDATE nodes SET {', '.join(fields)}, updated_at = ? WHERE id = ?''', values)
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        fields = []
        values = []
        for key, value in kwargs.items():
            if key in ('tags', 'ip_addresses', 'ip_aliases') and isinstance(value, (list, dict)):
                value = json.dumps(value)
            fields.append(f'''{key} = ?''')
            values.append(value)
        values.append(node_id)
        values.append(datetime.now().isoformat())
        cur.execute(f'''UPDATE nodes SET {', '.join(fields)}, updated_at = ? WHERE id = ?''', values)
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass


def get_current_vps_count(node_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM vps WHERE node_id = ?', (node_id,))
        count = cur.fetchone()[0]
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM vps WHERE node_id = ?', (node_id,))
        count = cur.fetchone()[0]
    with None:
        if not :
            pass

    except:
        pass


def get_vps_for_user(user_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        rows = cur.fetchall()
        vps_list = []
        for row in rows:
            vps = dict(row)
            
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                pass

            
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                [] = None

            
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else { }
            except:
                vps['metadata'] = { }

            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps_list.append(vps)
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        rows = cur.fetchall()
        vps_list = []
        for row in rows:
            vps = dict(row)
            
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                pass

            
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                [] = None

            
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else { }
            except:
                vps['metadata'] = { }

            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps_list.append(vps)
    with None:
        if not :
            pass

    except:
        pass


def get_all_vps():
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps ORDER BY created_at DESC')
        rows = cur.fetchall()
        vps_list = []
        for row in rows:
            vps = dict(row)
            
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                pass

            
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                [] = None

            
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else { }
            except:
                vps['metadata'] = { }

            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps_list.append(vps)
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps ORDER BY created_at DESC')
        rows = cur.fetchall()
        vps_list = []
        for row in rows:
            vps = dict(row)
            
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                pass

            
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                [] = None

            
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else { }
            except:
                vps['metadata'] = { }

            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps_list.append(vps)
    with None:
        if not :
            pass

    except:
        pass


def get_vps_by_id(vps_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            vps = dict(row)
            
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                pass

            
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                [] = None

            
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else { }
            except:
                vps['metadata'] = { }

            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            None(None, None)
            return 
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            vps = dict(row)
            
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                pass

            
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                [] = None

            
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else { }
            except:
                vps['metadata'] = { }

            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            None(None, None)
            return 
    with None:
        if not :
            pass

    except:
        pass


def get_vps_by_container(container_name):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE container_name = ?', (container_name,))
        row = cur.fetchone()
        if row:
            vps = dict(row)
            
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                pass

            
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                [] = None

            
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else { }
            except:
                vps['metadata'] = { }

            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            None(None, None)
            return 
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE container_name = ?', (container_name,))
        row = cur.fetchone()
        if row:
            vps = dict(row)
            
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                pass

            
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                [] = None

            
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else { }
            except:
                vps['metadata'] = { }

            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            None(None, None)
            return 
    with None:
        if not :
            pass

    except:
        pass


def create_vps(user_id, node_id, container_name, ram, cpu, storage, config, os_version, hostname = None, ip_address = None, ip_alias = None, expiration_days = 0, auto_suspend_enabled = False):
    now = datetime.now().isoformat()
    expires_at = None
    if auto_suspend_enabled and expiration_days > 0:
        expires_at = (datetime.now() + timedelta(days = expiration_days)).isoformat()
    
    try:
        conn = get_db()
        cur = conn.cursor()
        if not hostname:
            hostname
        cur.execute('INSERT INTO vps\n            (user_id, node_id, container_name, hostname, ram, cpu, storage, config, os_version,\n             status, created_at, updated_at, ip_address, ip_alias, shared_with, suspension_history, metadata,\n             expires_at, expiration_days, auto_suspend_enabled, renewal_count)\n            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (user_id, node_id, container_name, container_name, ram, cpu, storage, config, os_version, 'stopped', now, now, ip_address, ip_alias, '[]', '[]', '{}', expires_at, expiration_days, 1 if auto_suspend_enabled else 0, 0))
        conn.commit()
        vps_id = cur.lastrowid
        cur.execute('UPDATE nodes SET used_vps = (SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?', (node_id, node_id))
        conn.commit()
        log_activity(user_id, 'create_vps', 'vps', str(vps_id), {
            'container': container_name })
        if auto_suspend_enabled and expiration_days > 0:
            create_notification(user_id, 'success', 'VPS Created', f'''Your VPS {container_name} has been created successfully. It will auto-suspend in {expiration_days} days.''')
        else:
            create_notification(user_id, 'success', 'VPS Created', f'''Your VPS {container_name} has been created successfully.''')
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        conn = get_db()
        cur = conn.cursor()
        if not hostname:
            hostname
        cur.execute('INSERT INTO vps\n            (user_id, node_id, container_name, hostname, ram, cpu, storage, config, os_version,\n             status, created_at, updated_at, ip_address, ip_alias, shared_with, suspension_history, metadata,\n             expires_at, expiration_days, auto_suspend_enabled, renewal_count)\n            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (user_id, node_id, container_name, container_name, ram, cpu, storage, config, os_version, 'stopped', now, now, ip_address, ip_alias, '[]', '[]', '{}', expires_at, expiration_days, 1 if auto_suspend_enabled else 0, 0))
        conn.commit()
        vps_id = cur.lastrowid
        cur.execute('UPDATE nodes SET used_vps = (SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?', (node_id, node_id))
        conn.commit()
        log_activity(user_id, 'create_vps', 'vps', str(vps_id), {
            'container': container_name })
        if auto_suspend_enabled and expiration_days > 0:
            create_notification(user_id, 'success', 'VPS Created', f'''Your VPS {container_name} has been created successfully. It will auto-suspend in {expiration_days} days.''')
        else:
            create_notification(user_id, 'success', 'VPS Created', f'''Your VPS {container_name} has been created successfully.''')
    with None:
        if not :
            pass

    except:
        pass


def update_vps(vps_id, **kwargs):
    logger.info(f'''=== update_vps called for VPS {vps_id} ===''')
    logger.info(f'''Update parameters: {kwargs}''')
    
    try:
        conn = get_db()
        cur = conn.cursor()
        fields = []
        values = []
        for key, value in kwargs.items():
            if key in ('shared_with', 'suspension_history', 'metadata'):
                json_value = json.dumps(value)
                logger.info(f'''Converting {key} to JSON: {value} -> {json_value}''')
                value = json_value
            fields.append(f'''{key} = ?''')
            values.append(value)
        values.append(vps_id)
        values.append(datetime.now().isoformat())
        sql = f'''UPDATE vps SET {', '.join(fields)}, updated_at = ? WHERE id = ?'''
        logger.info(f'''Executing SQL: {sql}''')
        logger.info(f'''With values: {values}''')
        cur.execute(sql, values)
        conn.commit()
        logger.info(f'''Update committed. Rows affected: {cur.rowcount}''')
        cur.execute('SELECT shared_with FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            logger.info(f'''Verified shared_with in DB: {row[0]}''')
        else:
            logger.error(f'''VPS {vps_id} not found after update!''')

    None(None, None)
    return None
    with None:
        if not None:
            pass


def delete_vps(vps_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT container_name, user_id, node_id FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            (container_name, user_id, node_id) = row
            cur.execute('DELETE FROM port_forwards WHERE vps_container = ?', (container_name,))
        cur.execute('DELETE FROM vps WHERE id = ?', (vps_id,))
        conn.commit()
        if node_id:
            cur.execute('UPDATE nodes SET used_vps = (SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?', (node_id, node_id))
            conn.commit()
        log_activity(user_id, 'delete_vps', 'vps', str(vps_id), {
            'container': container_name })
        create_notification(user_id, 'info', 'VPS Deleted', f'''Your VPS {container_name} has been deleted.''')
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT container_name, user_id, node_id FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            (container_name, user_id, node_id) = row
            cur.execute('DELETE FROM port_forwards WHERE vps_container = ?', (container_name,))
        cur.execute('DELETE FROM vps WHERE id = ?', (vps_id,))
        conn.commit()
        if node_id:
            cur.execute('UPDATE nodes SET used_vps = (SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?', (node_id, node_id))
            conn.commit()
        log_activity(user_id, 'delete_vps', 'vps', str(vps_id), {
            'container': container_name })
        create_notification(user_id, 'info', 'VPS Deleted', f'''Your VPS {container_name} has been deleted.''')
    with None:
        if not :
            pass

    except:
        pass


def find_node_id_for_container(container_name):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT node_id FROM vps WHERE container_name = ?', (container_name,))
        row = cur.fetchone()

    None(None, None)
    return 
    with None:
        if not None, row[0] if row else 1:
            pass

utility_processor = (lambda : dict(now = datetime.now, get_current_vps_count = get_current_vps_count, get_setting = get_setting, get_unread_notifications_count = get_unread_notifications_count, OS_ICONS = OS_ICONS, get_os_label = get_os_label, get_os_icon_name = get_os_icon_name, is_vps_suspended = is_vps_suspended, is_vps_whitelisted = is_vps_whitelisted, PANEL_VERSION = PANEL_VERSION, PANEL_NAME = PANEL_NAME, PANEL_DEVELOPER = PANEL_DEVELOPER))()

def is_vps_suspended(vps):
    '''Check if VPS is suspended. Handles both boolean and integer values.'''
    suspended = vps.get('suspended', 0)
    if isinstance(suspended, bool):
        return suspended
    return None(suspended) == 1


def is_vps_whitelisted(vps):
    '''Check if VPS is whitelisted. Handles both boolean and integer values.'''
    whitelisted = vps.get('whitelisted', 0)
    if isinstance(whitelisted, bool):
        return whitelisted
    return None(whitelisted) == 1


def get_os_label(os_value):
    '''Get OS label from OS value'''
    for os_option in OS_OPTIONS:
        if not os_option['value'] == os_value:
            continue
        
        return None, os_option['label']
    return os_value


def get_os_icon_name(os_value):
    '''Get OS icon name from OS value'''
    for os_option in OS_OPTIONS:
        if not os_option['value'] == os_value:
            continue
        
        return None, os_option.get('icon', 'default')
    return 'default'


def refresh_vps_status(vps_id):
    '''Refresh VPS status from container and update database'''
    vps = get_vps_by_id(vps_id)
    if not vps:
        return None
    if is_vps_suspended(vps):
        return 'suspended'
    
    try:
        status = run_sync(get_container_status(vps['container_name'], vps['node_id']))
        if status != vps['status']:
            update_vps(vps_id, status = status)
    except Exception:
        e = None
        logger.error(f'''Error refreshing VPS {vps_id} status: {e}''')



def get_node_display_ip(node_id, use_alias = True):
    node = get_node(node_id)
    if not node:
        return None
    if use_alias and node['ip_aliases'] and len(node['ip_aliases']) > 0:
        return node['ip_aliases'][0]
    if None['ip_addresses'] and len(node['ip_addresses']) > 0:
        return node['ip_addresses'][0]


def get_node_all_ips(node_id):
    node = get_node(node_id)
    if not node:
        return []
    ips = None
    for alias in node.get('ip_aliases', []):
        ips.append({
            'type': 'alias',
            'value': alias })
    for ip in node.get('ip_addresses', []):
        ips.append({
            'type': 'ip',
            'value': ip })
    return ips


def get_vps_display_ip(vps):
    if vps.get('ip_alias'):
        return vps['ip_alias']
    return None.get('ip_address')


def format_ip_for_display(ip, port = None):
    if port:
        return f'''{ip}:{port}'''


def get_user_allocation(user_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT allocated_ports FROM port_allocations WHERE user_id = ?', (user_id,))
        row = cur.fetchone()

    None(None, None)
    return 
    with None:
        if not None, row[0] if row else 0:
            pass


def get_user_used_ports(user_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM port_forwards WHERE user_id = ?', (user_id,))
        row = cur.fetchone()

    None(None, None)
    return 
    with None:
        if not None, row[0] if row else 0:
            pass


def allocate_ports(user_id, amount):
    now = datetime.now().isoformat()
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('INSERT OR REPLACE INTO port_allocations (user_id, allocated_ports, used_ports, updated_at)\n                       VALUES (?, COALESCE((SELECT allocated_ports FROM port_allocations WHERE user_id = ?), 0) + ?, \n                               COALESCE((SELECT used_ports FROM port_allocations WHERE user_id = ?), 0), ?)', (user_id, user_id, amount, user_id, now))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('INSERT OR REPLACE INTO port_allocations (user_id, allocated_ports, used_ports, updated_at)\n                       VALUES (?, COALESCE((SELECT allocated_ports FROM port_allocations WHERE user_id = ?), 0) + ?, \n                               COALESCE((SELECT used_ports FROM port_allocations WHERE user_id = ?), 0), ?)', (user_id, user_id, amount, user_id, now))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass


def deallocate_ports(user_id, amount):
    now = datetime.now().isoformat()
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE port_allocations \n                       SET allocated_ports = MAX(0, allocated_ports - ?),\n                           updated_at = ?\n                       WHERE user_id = ?', (amount, now, user_id))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE port_allocations \n                       SET allocated_ports = MAX(0, allocated_ports - ?),\n                           updated_at = ?\n                       WHERE user_id = ?', (amount, now, user_id))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass


def get_available_host_port(node_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT host_port FROM port_forwards WHERE vps_container IN (SELECT container_name FROM vps WHERE node_id = ?)', (node_id,))
        used_ports = (lambda .0: if None:
passfor row in .0:
if row[0]:
passrow[0])(cur.fetchall()())
    with None:
        if not :
            pass

    None(None, None)
    for _ in range(100):
        port = random.randint(20000, 50000)
        if not port not in used_ports:
            continue
        
        return get_db(), port
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT host_port FROM port_forwards WHERE vps_container IN (SELECT container_name FROM vps WHERE node_id = ?)', (node_id,))
        used_ports = (lambda .0: if None:
passfor row in .0:
if row[0]:
passrow[0])(cur.fetchall()())
    with None:
        if not :
            pass

    except:
        pass
    continue


async def create_port_forward(user_id, container, vps_port, node_id, protocol = 'tcp,udp', description = ''):
    if None:
        pass
    host_port = get_available_host_port(node_id)
    if not host_port:
        return None
    
    try:
        if 'tcp' in protocol:
            if None or None:
                continue

    if 'udp' in protocol:
        if None or None:
            continue
    now = datetime.now().isoformat()
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('INSERT INTO port_forwards \n                (user_id, vps_container, vps_port, host_port, protocol, description, created_at, last_used, hits)\n                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', (user_id, container, vps_port, host_port, protocol, description, now, now, 0))
        conn.commit()
        cur.execute('UPDATE port_allocations SET used_ports = used_ports + 1, updated_at = ? WHERE user_id = ?', (now, user_id))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    log_activity(user_id, 'create_port_forward', 'port', str(host_port), {
        'container': container,
        'vps_port': vps_port,
        'host_port': host_port,
        'protocol': protocol })
    create_notification(user_id, 'success', 'Port Forward Created', f'''Port {vps_port} forwarded to port {host_port} on {container}''')
    if socketio:
        socketio.emit('port_forward_created', {
            'host_port': host_port,
            'vps_port': vps_port,
            'container': container }, room = f'''user_{user_id}''')
    return host_port
    continue
    continue
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('INSERT INTO port_forwards \n                (user_id, vps_container, vps_port, host_port, protocol, description, created_at, last_used, hits)\n                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', (user_id, container, vps_port, host_port, protocol, description, now, now, 0))
        conn.commit()
        cur.execute('UPDATE port_allocations SET used_ports = used_ports + 1, updated_at = ? WHERE user_id = ?', (now, user_id))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass
    execute_lxc(container, f'''config device add {container} udp_proxy_{host_port} proxy listen=udp:0.0.0.0:{host_port} connect=udp:127.0.0.1:{vps_port}''', node_id = node_id)
    execute_lxc(container, f'''config device add {container} tcp_proxy_{host_port} proxy listen=tcp:0.0.0.0:{host_port} connect=tcp:127.0.0.1:{vps_port}''', node_id = node_id)
    continue
    except Exception:
        e = None
        logger.error(f'''Failed to create port forward: {e}''')
    e = None
    del e
    return None
    e = None
    del e


async def remove_port_forward(forward_id):
    if None:
        pass
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT user_id, vps_container, host_port, protocol FROM port_forwards WHERE id = ?', (forward_id,))
        row = cur.fetchone()
        if not row:
            None(None, None)
            return (False, None)

    (user_id, container, host_port, protocol) = row
    None(None, None)
    node_id = find_node_id_for_container(container)
    
    try:
        if 'tcp' in protocol:
            
            try:
                if None or None:
                    continue


    if 'udp' in protocol:
        
        try:
            if None or None:
                continue

    now = datetime.now().isoformat()
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('DELETE FROM port_forwards WHERE id = ?', (forward_id,))
        conn.commit()
        cur.execute('UPDATE port_allocations SET used_ports = used_ports - 1, updated_at = ? WHERE user_id = ?', (now, user_id))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    log_activity(user_id, 'remove_port_forward', 'port', str(host_port))
    create_notification(user_id, 'info', 'Port Forward Removed', f'''Port forward {host_port} has been removed.''')
    if socketio:
        socketio.emit('port_forward_removed', {
            'host_port': host_port,
            'container': container }, room = f'''user_{user_id}''')
    return (True, user_id)
    with None:
        if not get_db():
            pass
    execute_lxc(container, f'''config device remove {container} udp_proxy_{host_port}''', node_id = node_id)
    execute_lxc(container, f'''config device remove {container} tcp_proxy_{host_port}''', node_id = node_id)
    continue
    continue
    continue
    continue
    continue
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('DELETE FROM port_forwards WHERE id = ?', (forward_id,))
        conn.commit()
        cur.execute('UPDATE port_allocations SET used_ports = used_ports - 1, updated_at = ? WHERE user_id = ?', (now, user_id))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass
    continue
    except Exception:
        e = None
        logger.error(f'''Failed to remove port forward {forward_id}: {e}''')
    e = None
    del e
    return (False, None)
    e = None
    del e


def get_user_forwards(user_id):
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM port_forwards WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        rows = cur.fetchall()
    with None:
        if not :
            pass

    for None in :
        pass
    None(None, None)
    return 
    
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT * FROM port_forwards WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        rows = cur.fetchall()
    with None:
        if not :
            pass

    except:
        pass
    None, None, None, get_db(), [], row,


async def recreate_port_forwards(container_name):
    if None:
        pass
    node_id = find_node_id_for_container(container_name)
    readded_count = 0
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT vps_port, host_port, protocol FROM port_forwards WHERE vps_container = ?', (container_name,))
        rows = cur.fetchall()
    with None:
        if not :
            pass

    None(None, None)
    for row in rows:
        protocol = row['protocol']
        host_port = row['host_port']
        vps_port = row['vps_port']
        
        try:
            if 'tcp' in protocol:
                if None or None:
                    continue

        if 'udp' in protocol:
            if None or None:
                continue
        logger.info(f'''Re-added port forward {host_port}->{vps_port} for {container_name}''')
        readded_count += 1
    return readded_count
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT vps_port, host_port, protocol FROM port_forwards WHERE vps_container = ?', (container_name,))
        rows = cur.fetchall()
    with None:
        if not :
            pass

    except:
        pass
    continue
    continue
    continue
    except Exception:
        e = None
        logger.error(f'''Failed to re-add port forward {host_port}->{vps_port} for {container_name}: {e}''')
    e = None
    del e
    continue
    e = None
    del e


async def update_port_forward_hit(host_port):
    if None:
        pass
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE port_forwards SET hits = hits + 1, last_used = ? WHERE host_port = ?', (datetime.now().isoformat(), host_port))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE port_forwards SET hits = hits + 1, last_used = ? WHERE host_port = ?', (datetime.now().isoformat(), host_port))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass


def relativeTime(dt):
    if not dt:
        return 'Never'
    if isinstance(dt, str):
        
        try:
            dt = datetime.fromisoformat(dt)
        except:
            pass

        now = datetime.now()
        diff = now - dt
        seconds = int(diff.total_seconds())
        if seconds < 60:
            return 'just now'
    if seconds < 3600:
        return f'''{seconds // 60} minutes ago'''
    if None < 86400:
        return f'''{seconds // 3600} hours ago'''
    if None < 604800:
        return f'''{seconds // 86400} days ago'''
    return None.strftime('%Y-%m-%d')


def get_host_cpu_usage():
    '''Get host CPU usage with multiple fallback methods'''
    
    try:
        import psutil
        cpu_percent = psutil.cpu_percent(interval = 0.5)
        if cpu_percent:
            return float(cpu_percent)
    except ImportError:
        pass
    continue
    except Exception:
        logger.debug(f'''psutil CPU method failed: {e}''')

    if shutil.which('mpstat'):
        
        try:
            result = subprocess.run([
                'mpstat',
                '1',
                '1'], capture_output = True, text = True, timeout = 3)
            if result.returncode == 0:
                output = result.stdout
                for line in output.split('\n'):
                    if not 'all' in line.lower():
                        continue
                    if not '%' in line:
                        continue
                    parts = line.split()
                    for i, part in enumerate(parts):
                        if not 'idle' in part.lower():
                            continue
                        
                        try:
                            idle = float(parts[i + 1] if i + 1 < len(parts) else parts[-1])
                        except:
                            pass

                        
                        
                        return None, None, None
                    
                    try:
                        pass
                    except:
                        pass

                    
                    return None, None

    
    try:
        
        def get_cpu_times()():
            
            try:
                f = open('/proc/stat', 'r')
                line = f.readline()
            with None:
                if not :
                    pass

            for None in :
                pass
            open('/proc/stat', 'r'), [], values = None
            x = None
            None(None, None)
            return 
            
            
            try:
                f = open('/proc/stat', 'r')
                line = f.readline()
            with None:
                if not :
                    pass

            except:
                pass
            None, None, None, values

        time.sleep(0.5)
        times2 = get_cpu_times()
    except Exception:
        i, e = None, None, None
        logger.debug(f'''/proc/stat method failed: {e}''')

    for None in :
        pass
    None, [], deltas = None
    i = None
    total_delta = sum(deltas)
    if total_delta > 0:
        idle_delta = deltas[3]
        cpu_usage = 100 * (total_delta - idle_delta) / total_delta
        return max(0, min(100, cpu_usage))
    
    try:
        result = subprocess.run([
            'top',
            '-bn1'], capture_output = True, text = True, timeout = 3)
        if result.returncode == 0:
            for line in result.stdout.split('\n'):
                if not 'Cpu' in line and 'CPU' in line:
                    continue
                import re
                idle_match = re.search('(\\d+\\.?\\d*)\\s*%?\\s*id', line)
                if not idle_match:
                    continue
                idle = float(idle_match.group(1))
                
                return None, max(0, min(100, 100 - idle))

    logger.warning('All CPU usage methods failed, returning 0.0')
    return 0
    if Exception:
        e = None
        logger.debug(f'''mpstat method failed: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    
    if Exception:
        e = None
        logger.debug(f'''top method failed: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    if Exception:
        e = None
        logger.error(f'''Error getting CPU usage: {e}''')
        e = None
        del e
        return 0
        e = None
        del e


def get_host_ram_usage():
    '''Get host RAM usage with multiple fallback methods'''
    
    try:
        import psutil
        mem = psutil.virtual_memory()
    except ImportError:
        
        try:
            pass
        except Exception:
            e = None
            logger.debug(f'''psutil RAM method failed: {e}''')
        e = None
        del e
        except:
            e = None
            del e
        
        try:
            result = subprocess.run([
                'free',
                '-m'], capture_output = True, text = True, timeout = 3)
            if result.returncode == 0:
                lines = result.stdout.splitlines()



    return None
    
    try:
        import psutil
        mem = psutil.virtual_memory()
    except ImportError:
        
        try:
            pass
        except Exception:
            e = None
            logger.debug(f'''psutil RAM method failed: {e}''')
        e = None
        del e
        except:
            e = None
            del e
        
        try:
            result = subprocess.run([
                'free',
                '-m'], capture_output = True, text = True, timeout = 3)
            if result.returncode == 0:
                lines = result.stdout.splitlines()



    
    try:
        pass
    except Exception:
        logger.debug(f'''/proc/meminfo method failed: {e}''')
    None = None
    del e
    except:
        e = None
        del e

    
    try:
        f = None if len(lines) > 1 else None
        meminfo = { }
        for line in f:
            parts = line.split(':')
            if not len(parts) == 2:
                continue
            key = parts[0].strip()
            value = parts[1].strip().split()[0]
            meminfo[key] = int(value)
    with None:
        if not :
            pass

    total = meminfo.get('MemTotal', 0) // 1024
    free = meminfo.get('MemFree', 0) // 1024
    buffers = meminfo.get('Buffers', 0) // 1024
    cached = meminfo.get('Cached', 0) // 1024
    if total > 0:
        available = free + buffers + cached
        used = total - available
        None(None, None)
        return 
    None(None, None)
    
    try:
        f = None if len(lines) > 1 else None
        meminfo = { }
        for line in f:
            parts = line.split(':')
            if not len(parts) == 2:
                continue
            key = parts[0].strip()
            value = parts[1].strip().split()[0]
            meminfo[key] = int(value)
    with None:
        if not :
            pass

    except:
        pass
    logger.warning('All RAM usage methods failed, returning zeros')
    return {
        'total': 0,
        'used': 0,
        'free': 0,
        'percent': 0 }
    except Exception:
        e = None
        logger.error(f'''Error getting RAM usage: {e}''')
    del e
    return None
    None = None
    del e
    except Exception:
        e = None
        logger.error(f'''Error getting RAM usage: {e}''')
    del e
    return None
    None = None
    del e


def get_host_disk_usage():
    '''Get host disk usage with multiple fallback methods'''
    
    try:
        import psutil
        usage = psutil.disk_usage('/')
    except ImportError:
        
        try:
            pass
        except Exception:
            e = None
            logger.debug(f'''psutil disk method failed: {e}''')
        e = None
        del e
        except:
            e = None
            del e
        
        try:
            import shutil
            usage = shutil.disk_usage('/')
            total_gb = usage.total / 1073741824
            used_gb = usage.used / 1073741824
            free_gb = usage.free / 1073741824
            percent = (usage.used / usage.total) * 100 if usage.total > 0 else 0
        except Exception:
            e = None
            logger.debug(f'''shutil disk method failed: {e}''')
        e = None
        del e
        except:
            e = None
            del e

        return None
        
        try:
            result = subprocess.run([
                'df',
                '-h',
                '/'], capture_output = True, text = True, timeout = 3)
            if result.returncode == 0:
                lines = result.stdout.splitlines()



    return None
    
    try:
        import psutil
        usage = psutil.disk_usage('/')
    except ImportError:
        
        try:
            pass
        except Exception:
            e = None
            logger.debug(f'''psutil disk method failed: {e}''')
        e = None
        del e
        except:
            e = None
            del e
        
        try:
            import shutil
            usage = shutil.disk_usage('/')
            total_gb = usage.total / 1073741824
            used_gb = usage.used / 1073741824
            free_gb = usage.free / 1073741824
            percent = (usage.used / usage.total) * 100 if usage.total > 0 else 0
        except Exception:
            e = None
            logger.debug(f'''shutil disk method failed: {e}''')
        e = None
        del e
        except:
            e = None
            del e

        return None
        
        try:
            result = subprocess.run([
                'df',
                '-h',
                '/'], capture_output = True, text = True, timeout = 3)
            if result.returncode == 0:
                lines = result.stdout.splitlines()



    
    try:
        import os
        stat = os.statvfs('/')
        total = stat.f_blocks * stat.f_frsize
        free = stat.f_bavail * stat.f_frsize
        used = total - free
        total_gb = total / 1073741824
        used_gb = used / 1073741824
        free_gb = free / 1073741824
        percent = (used / total) * 100 if total > 0 else 0
    except Exception:
        e = None
        logger.debug(f'''statvfs method failed: {e}''')
    e = None
    del e
    except:
        e = None
        del e

    return None if len(lines) > 1 else None
    logger.warning('All disk usage methods failed, returning Unknown')
    return {
        'total': 'Unknown',
        'used': 'Unknown',
        'free': 'Unknown',
        'percent': 'Unknown' }
    except Exception:
        e = None
        logger.error(f'''Error getting disk usage: {e}''')
    del e
    return None
    None = None
    del e


def get_host_uptime():
    
    try:
        pass
    except:
        pass

    
    try:
        f = None
        uptime_seconds = float(f.readline().split()[0])
        days = int(uptime_seconds // 86400)
        hours = int((uptime_seconds % 86400) // 3600)
        minutes = int((uptime_seconds % 3600) // 60)
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        f = None
        uptime_seconds = float(f.readline().split()[0])
        days = int(uptime_seconds // 86400)
        hours = int((uptime_seconds % 86400) // 3600)
        minutes = int((uptime_seconds % 3600) // 60)
    with None:
        if not :
            pass

    except:
        pass


async def get_host_stats(node_id):
    '''Get host statistics with improved error handling and caching'''
    if None:
        pass
    node = get_node(node_id)
    if not node:
        logger.warning(f'''Node {node_id} not found''')
        return {
            'cpu': 0,
            'ram': {
                'total': 0,
                'used': 0,
                'free': 0,
                'percent': 0 },
            'disk': {
                'total': 'Unknown',
                'used': 'Unknown',
                'free': 'Unknown',
                'percent': 'Unknown' },
            'uptime': 'Unknown' }
    if None['is_local']:
        
        try:
            stats = {
                'cpu': get_host_cpu_usage(),
                'ram': get_host_ram_usage(),
                'disk': get_host_disk_usage(),
                'uptime': get_host_uptime() }
            logger.debug(f'''Local node {node_id} stats: CPU={stats['cpu']:.1f}%, RAM={stats['ram']['percent']:.1f}%''')
        except Exception:
            e = None
            logger.error(f'''Error getting local node stats: {e}''', exc_info = True)

        return None
    
    try:
        import requests
        url = f'''{node['url']}/api/host/stats'''
        headers = {
            'X-API-Key': node['api_key'] }
        verify_ssl = bool(node.get('verify_ssl', 1))
        logger.debug(f'''Fetching stats from remote node {node['name']}: {url} (verify_ssl={verify_ssl})''')
        response = requests.get(url, headers = headers, timeout = 10, verify = verify_ssl)
        response.raise_for_status()
        stats = response.json()
        logger.debug(f'''Remote node {node['name']} stats received: {stats}''')
    except requests.exceptions.Timeout:
        logger.warning(f'''Timeout connecting to node {node['name']}''')
        mark_node_offline(node_id)
    return None
    except requests.exceptions.ConnectionError:
        logger.warning(f'''Connection error to node {node['name']}''')
        mark_node_offline(node_id)
    return None
    except Exception:
        logger.error(f'''Failed to get host stats from node {node['name']}: {e}''', exc_info = True)
        mark_node_offline(node_id)

    
    try:
        pass
    except Exception:
        db_err = None
        logger.error(f'''Failed to update node {node_id} in database: {db_err}''')

    
    try:
        conn = None
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET \n                                  status = ?, \n                                  last_seen = ?, \n                                  cpu_cores = ?, \n                                  ram_total = ?, \n                                  disk_total = ? \n                                  WHERE id = ?', ('online', datetime.now().isoformat(), stats.get('cpu_cores', 0), stats.get('ram', { }).get('total', 0), stats.get('disk', { }).get('total_gb', 0), node_id))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return stats
    
    try:
        conn = None
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET \n                                  status = ?, \n                                  last_seen = ?, \n                                  cpu_cores = ?, \n                                  ram_total = ?, \n                                  disk_total = ? \n                                  WHERE id = ?', ('online', datetime.now().isoformat(), stats.get('cpu_cores', 0), stats.get('ram', { }).get('total', 0), stats.get('disk', { }).get('total_gb', 0), node_id))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass
    return stats


def mark_node_offline(node_id):
    '''Helper function to mark a node as offline'''
    
    try:
        pass
    except Exception:
        e = None
        logger.error(f'''Failed to mark node {node_id} offline: {e}''')

    
    try:
        conn = None
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?', ('offline', datetime.now().isoformat(), node_id))
        conn.commit()
    with None:
        if not :
            pass

    None(None, None)
    return None
    
    try:
        conn = None
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?', ('offline', datetime.now().isoformat(), node_id))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass


async def get_node_status(node_id):
    '''Get node status with improved error handling'''
    if None:
        pass
    node = get_node(node_id)
    if not node:
        logger.warning(f'''Node {node_id} not found for status check''')
        return {
            'status': '❓ Unknown',
            'online': False }
    if None['is_local']:
        
        try:
            if None or None:
                continue

        stats = None
        return {
            'status': '🟢 Online (Local)',
            'online': True,
            'local': True,
            'last_seen': datetime.now().isoformat(),
            'stats': stats }
    
    try:
        import requests
        headers = {
            'X-API-Key': node['api_key'] }
        verify_ssl = bool(node.get('verify_ssl', 1))
        logger.debug(f'''Pinging remote node {node['name']}: {node['url']}/api/ping (verify_ssl={verify_ssl})''')
        response = requests.get(f'''{node['url']}/api/ping''', headers = headers, timeout = 5, verify = verify_ssl)
        if response.status_code == 200:
            data = response.json()
            now = datetime.now().isoformat()
            
            try:
                pass
            except Exception:
                db_err = None
                logger.error(f'''Failed to update node {node_id} status in database: {db_err}''')

            
            try:
                conn = None
                cur = conn.cursor()
                cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?', ('online', now, node_id))
                conn.commit()
            with None:
                if not :
                    pass

            None(None, None)
            if None or None:
                continue
            stats = None
            return {
                'status': '🟢 Online',
                'online': True,
                'local': False,
                'last_seen': now,
                'stats': stats,
                'ping_time': data.get('time') }
    except requests.exceptions.Timeout:
        logger.warning(f'''Timeout pinging node {node['name']}''')
        mark_node_offline(node_id)
    return None
    except requests.exceptions.ConnectionError:
        logger.warning(f'''Connection error to node {node['name']}''')
        mark_node_offline(node_id)
    return None
    except Exception:
        logger.error(f'''Failed to ping node {node['name']}: {e}''', exc_info = True)
        mark_node_offline(node_id)

    None.warning(f'''Node {node['name']} returned status {response.status_code}''')
    mark_node_offline(node_id)
    return {
        'status': '🔴 Offline',
        'online': False,
        'local': False,
        'last_seen': node.get('last_seen') }
    continue
    if Exception:
        e = None
        logger.error(f'''Error getting local node status: {e}''')
        del e
        return None
    None = None
    del e
    
    try:
        conn = None
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?', ('online', now, node_id))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass
    continue
    continue


async def get_container_status(container_name, node_id = None):
    '''Get container status with improved error handling'''
    if None:
        pass
    if node_id:
        node_id = find_node_id_for_container(container_name)
    
    try:
        if None or None:
            continue

    result = None
    for line in result.split('\n'):
        if not line.startswith('Status: '):
            continue
        status = line.split(': ', 1)[1].strip().lower()
        logger.debug(f'''Container {container_name} status: {status}''')
        
        return execute_lxc(container_name, f'''info {container_name}''', node_id = node_id, timeout = 5), status
    logger.warning(f'''Status line not found for container {container_name}''')
    return 'unknown'
    continue
    if Exception:
        logger.error(f'''Error getting status for {container_name}: {e}''')
        None = None
        del e
        return 'unknown'
        e = None
        del e


async def get_container_stats(container_name, node_id = None):
    '''Get container statistics with improved error handling and data transformation'''
    if None:
        pass
    if node_id:
        node_id = find_node_id_for_container(container_name)
    node = get_node(node_id)
    if not node:
        logger.warning(f'''Node {node_id} not found for container {container_name}''')
        return {
            'status': 'unknown',
            'cpu': 0,
            'ram': {
                'used': 0,
                'total': 0,
                'pct': 0 },
            'disk': {
                'use_percent': '0%' },
            'uptime': 'Unknown' }
    if node_id['is_local']:
        
        try:
            if None or None:
                continue

        status = None
        return {
            'status': status,
            'cpu': cpu,
            'ram': ram,
            'disk': disk,
            'uptime': uptime,
            'processes': processes,
            'network': network }
    
    try:
        import requests
        url = f'''{node['url']}/api/container/stats'''
        data = {
            'container': container_name }
        headers = {
            'X-API-Key': node['api_key'] }
        verify_ssl = bool(node.get('verify_ssl', 1))
        logger.debug(f'''Fetching container stats from {node['name']}: {url} (verify_ssl={verify_ssl})''')
        response = requests.post(url, json = data, headers = headers, timeout = 10, verify = verify_ssl)
        response.raise_for_status()
        stats = response.json()
        ram_data = stats.get('ram', {
            'used': 0,
            'total': 0,
            'percent': 0 })
        if isinstance(ram_data, dict):
            if 'percent' in ram_data and 'pct' not in ram_data:
                ram_data['pct'] = ram_data['percent']
            if 'pct' not in ram_data:
                ram_data['pct'] = 0
            else:
                ram_data = {
                    'used': 0,
                    'total': 0,
                    'pct': 0 }
        disk_data = stats.get('disk', 'Unknown')
        if isinstance(disk_data, str):
            if disk_data in ('Unknown', 'Stopped', 'N/A'):
                disk_data = {
                    'size': 'Unknown',
                    'used': 'Unknown',
                    'available': 'Unknown',
                    'use_percent': '0%' }
            else:
                import re
                match = re.match('(.+?)/(.+?)\\s*\\((.+?)\\)', disk_data)
                if match:
                    (used, total, percent) = match.groups()
                    disk_data = {
                        'size': total.strip(),
                        'used': used.strip(),
                        'available': 'Unknown',
                        'use_percent': percent.strip() }
                else:
                    disk_data = {
                        'size': 'Unknown',
                        'used': 'Unknown',
                        'available': 'Unknown',
                        'use_percent': '0%' }
        elif not isinstance(disk_data, dict):
            disk_data = {
                'use_percent': '0%' }
        if 'use_percent' not in disk_data:
            disk_data['use_percent'] = '0%'
    except requests.exceptions.Timeout:
        logger.warning(f'''Timeout getting container stats from node {node['name']}''')
    return None
    except requests.exceptions.ConnectionError:
        logger.warning(f'''Connection error getting container stats from node {node['name']}''')
    return None
    except Exception:
        logger.error(f'''Failed to get container stats from node {node['name']}: {e}''', exc_info = True)

    return None
    continue
    continue
    continue
    continue
    continue
    continue
    continue
    if Exception:
        e = None
        logger.error(f'''Error getting local container stats for {container_name}: {e}''', exc_info = True)
        del e
        return None
    None = None
    del e


async def get_container_cpu_pct_local(container_name, node_id):
    '''Get container CPU usage - simplified and reliable method'''
    if None:
        pass
    
    try:
        simple_script = 'sh -c \'\ncat /proc/stat | grep "^cpu " > /tmp/cpu1\nsleep 1\ncat /proc/stat | grep "^cpu " > /tmp/cpu2\nawk "{\n    getline < \\"/tmp/cpu1\\"\n    u1=\\$2; n1=\\$3; s1=\\$4; i1=\\$5\n    getline < \\"/tmp/cpu2\\"\n    u2=\\$2; n2=\\$3; s2=\\$4; i2=\\$5\n    total=(u2-u1)+(n2-n1)+(s2-s1)+(i2-i1)\n    used=(u2-u1)+(n2-n1)+(s2-s1)\n    if(total>0) print (used*100)/total; else print 0\n}" /tmp/cpu2\nrm -f /tmp/cpu1 /tmp/cpu2\n\''
    except Exception:
        e = None
        logger.error(f'''Error getting CPU for {container_name}: {e}''')

    
    try:
        if None or None:
            continue
            result = None

    cpu_pct = float(result.strip())
    if  <= 0, cpu_pct or 0, cpu_pct <= 100:
        pass
    else:
        execute_lxc(container_name, f'''exec {container_name} -- {simple_script}''', node_id = node_id)
    logger.debug(f'''CPU for {container_name}: {cpu_pct}%''')
    return round(cpu_pct, 2)
    
    try:
        if None or None:
            continue

    if result:
        import re = None
        idle_match = re.search('(\\d+\\.?\\d*)\\s*id', result)
        if idle_match:
            idle = float(idle_match.group(1))
            cpu_pct = 100 - idle
            logger.debug(f'''CPU for {container_name} (top): {cpu_pct}%''')
            return round(cpu_pct, 2)
        
        try:
            if None or None:
                continue
                result = None

    if result:
        parts = result.split()
        if len(parts) >= 15:
            idle = float(parts[14])
            cpu_pct = 100 - idle
            logger.debug(f'''CPU for {container_name} (vmstat): {cpu_pct}%''')
            return round(cpu_pct, 2)
        
        try:
            if None or None:
                continue
                result = None

    for None in :
        if not line.startswith('cpu '):
            continue
    , [], lines = execute_lxc(container_name, f'''exec {container_name} -- sh -c \'grep "^cpu " /proc/stat && sleep 1 && grep "^cpu " /proc/stat\'''', node_id = node_id), result.split('\n')
    line = execute_lxc(container_name, f'''exec {container_name} -- sh -c \'vmstat 1 2 | tail -1\'''', node_id = node_id)
    if len(lines) >= 2:
        for None in :
            pass
        , [], fields1 = execute_lxc(container_name, f'''exec {container_name} -- sh -c \'top -bn1 | grep "Cpu(s)"\'''', node_id = node_id), lines[0].split()[1:8]
        x = execute_lxc(container_name, f'''exec {container_name} -- {simple_script}''', node_id = node_id)
        total1 = sum(fields1)
        idle1 = fields1[3]
        for None in :
            pass
        , [], fields2 = None, lines[1].split()[1:8]
        x = None
        total2 = sum(fields2)
        idle2 = fields2[3]
        total_delta = total2 - total1
        idle_delta = idle2 - idle1
        if total_delta > 0:
            cpu_pct = 100 * (total_delta - idle_delta) / total_delta
            logger.debug(f'''CPU for {container_name} (/proc/stat): {cpu_pct}%''')
            return round(cpu_pct, 2)
        None.warning(f'''All CPU detection methods failed for {container_name}, returning 0''')
        return 0
        continue
        if Exception:
            e = None
            logger.debug(f'''Simple sh script failed for {container_name}: {e}''')
            e = None
            del e
            continue
            e = None
            del e
    continue
    if Exception:
        e = None
        logger.debug(f'''Top method failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    continue
    if Exception:
        e = None
        logger.debug(f'''vmstat method failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    continue
    
    
    
    if Exception:
        x, e = None, None, None, None, None, line,, x,
        logger.debug(f'''/proc/stat method failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e


async def get_container_ram_local(container_name, node_id):
    if None:
        pass
    
    try:
        if None or None:
            continue

    result = None
    lines = result.split('\n')
    if len(lines) > 1:
        parts = lines[1].split()
        total = int(parts[1])
        used = int(parts[2])
        free = int(parts[3])
        pct = (used / total) * 100 if total > 0 else 0
        return {
            'used': used,
            'total': total,
            'free': free,
            'pct': pct }
    return {
        'used': execute_lxc(container_name, f'''exec {container_name} -- free -m''', node_id = node_id),
        'total': 0,
        'free': 0,
        'pct': 0 }
    continue
    if Exception:
        e = None
        logger.error(f'''Error getting RAM for {container_name}: {e}''')
        del e
        return None
    None = None
    del e


async def get_container_disk_local(container_name, node_id):
    if None:
        pass
    
    try:
        if None or None:
            continue

    result = None
    lines = result.strip().split('\n')
    if len(lines) >= 2:
        for line in lines[1:]:
            parts = line.split()
            if len(parts) >= 6:
                (filesystem, size, used, avail, usep, mount) = parts[:6]
                
                return execute_lxc(container_name, f'''exec {container_name} -- df -h /''', node_id = node_id), {
                    'filesystem': filesystem,
                    'size': size,
                    'used': used,
                    'available': avail,
                    'use_percent': usep,
                    'mounted': mount }
            if not execute_lxc(container_name, f'''exec {container_name} -- df -h /''', node_id = node_id)(parts) >= 5:
                continue
            (size, used, avail, usep) = (parts[0], parts[1], parts[2], parts[3])
            
            return None, {
                'filesystem': 'rootfs',
                'size': size,
                'used': used,
                'available': avail,
                'use_percent': usep,
                'mounted': '/' }
    
    try:
        if None or None:
            continue

    result.strip().split('\n') = None
    if len(lines) >= 2:
        parts = lines[1].split()
        if len(parts) >= 5:
            return {
                'filesystem': parts[0],
                'size': parts[1],
                'used': parts[2],
                'available': parts[3],
                'use_percent': parts[4],
                'mounted': parts[5] if len(parts) > 5 else '/' }
        return {
            'size': execute_lxc(container_name, f'''exec {container_name} -- df -hP /''', node_id = node_id),
            'used': 'Unknown',
            'available': 'Unknown',
            'use_percent': '0%' }
    continue
    continue
    if Exception:
        e = execute_lxc(container_name, f'''exec {container_name} -- df -hP /''', node_id = node_id)
        logger.debug(f'''df -hP fallback failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    if Exception:
        e = None
        logger.error(f'''Error getting disk for {container_name}: {e}''')
        del e
        return None
    None = None
    del e


async def get_container_uptime_local(container_name, node_id):
    '''Get container uptime with improved parsing'''
    if None:
        pass
    
    try:
        if None or None:
            continue

    result = None
    if result and result.strip():
        return result.strip()
    
    try:
        if None or None:
            continue

    result = None
    if result and result.strip():
        return result.strip()
    
    try:
        if None or None:
            continue

    result = None
    if result:
        uptime_seconds = float(result.split()[0])
        days = int(uptime_seconds // 86400)
        hours = int((uptime_seconds % 86400) // 3600)
        minutes = int((uptime_seconds % 3600) // 60)
        parts = []
        if days > 0:
            parts.append(f'''{days}d''')
        if hours > 0:
            parts.append(f'''{hours}h''')
        if not minutes > 0 or parts:
            parts.append(f'''{minutes}m''')
        return ' '.join(parts)
    logger.warning(f'''All uptime methods failed for {container_name}''')
    return 'Unknown'
    continue
    if Exception:
        e = execute_lxc(container_name, f'''exec {container_name} -- cat /proc/uptime''', node_id = node_id, timeout = 3)
        logger.debug(f'''uptime -p failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    continue
    if Exception:
        e = None
        logger.debug(f'''uptime failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    continue
    if Exception:
        e = None
        logger.debug(f'''/proc/uptime failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e


async def get_container_processes_local(container_name, node_id):
    '''Get container process count with improved error handling'''
    if None:
        pass
    
    try:
        if None or None:
            continue

    result = None
    if result and result.strip().isdigit():
        count = int(result.strip()) - 1
        return max(0, count)
    
    try:
        if None or None:
            continue

    result = None
    if result and result.strip().isdigit():
        count = int(result.strip()) - 1
        return max(0, count)
    
    try:
        if None or None:
            continue

    result = None
    if result and result.strip().isdigit():
        return int(result.strip())
    execute_lxc(container_name, f'''exec {container_name} -- sh -c \'ls -d /proc/[0-9]* | wc -l\'''', node_id = node_id, timeout = 3).warning(f'''All process count methods failed for {container_name}''')
    return 0
    continue
    if Exception:
        e = execute_lxc(container_name, f'''exec {container_name} -- sh -c \'ps -e | wc -l\'''', node_id = node_id, timeout = 3)
        logger.debug(f'''ps aux method failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    continue
    if Exception:
        e = None
        logger.debug(f'''ps -e method failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    continue
    if Exception:
        e = None
        logger.debug(f'''/proc count method failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e


async def get_container_network_local(container_name, node_id):
    '''Get container network information with improved parsing'''
    if None:
        pass
    ips = []
    
    try:
        if None or None:
            continue

    result = None
    if result:
        for line in result.split('\n'):
            if not 'inet ' in line:
                continue
            if not '127.0.0.1' not in line:
                continue
            parts = line.strip().split()
            if not len(parts) >= 2:
                continue
            ip = parts[1].split('/')[0]
            if not ip not in ips:
                continue
            ips.append(ip)
    if not ips:
        
        try:
            if None or None:
                continue

        result = None
        if result:
            for ip in result.strip().split():
                if not ip:
                    continue
                if not ip != '127.0.0.1':
                    continue
                if not ip not in ips:
                    continue
                ips.append(ip)
        return {
            'ips': ips }
    return {
        None: ips }
    continue
    if Exception:
        e = None
        logger.debug(f'''ip addr method failed for {container_name}: {e}''')
        e = None
        del e
        continue
        e = None
        del e
    continue
    if Exception:
        e = None
        logger.debug(f'''hostname -I method failed for {container_name}: {e}''')
        e = None
        del e
        return {
            'ips': ips }
    e = None
    del e


async def get_container_private_ip(container_name, node_id):
    '''Get the private IP address of the container (internal LXC IP)'''
    if None:
        pass
    
    try:
        if None or None:
            continue

    result = None
    if result:
        ips = result.strip().split()
        if ips:
            return ips[0]
        if None or None:
            continue
    result = None
    if result:
        for line in result.split('\n'):
            if not 'inet ' in line:
                continue
            if not '127.0.0.1' not in line:
                continue
            parts = line.strip().split()
            if not len(parts) >= 2:
                continue
            ip = parts[1].split('/')[0]
            if ip.startswith('127.'):
                continue
            
            return execute_lxc(container_name, f'''exec {container_name} -- sh -c \'hostname -I\'''', node_id = node_id)(container_name, f'''exec {container_name} -- ip addr show''', node_id = node_id), ip
    return 'N/A'
    continue
    continue
    if Exception:
        logger.error(f'''Error getting private IP for {container_name}: {e}''')
        None = None
        del e
        return 'N/A'
        e = None
        del e

from api import api_bp
app.register_blueprint(api_bp)
logger.info('API blueprint registered at /api/v1')
index = (lambda : if current_user.is_authenticated:
redirect(url_for('dashboard'))None('index.html', panel_name = get_setting('site_name', 'SVM PANEL')))()
activate_license_page = (lambda : license_info = get_license_info()render_template('activate_license.html', panel_name = get_setting('site_name', 'SVM PANEL'), license_info = license_info))()
activate_license_submit = (lambda : data = request.get_json() if request.is_json else request.formlicense_key = data.get('license_key', '').strip()if not license_key:
if request.is_json:
(jsonify({
'success': False,
'error': 'License key is required' }), 400)None('License key is required', 'danger')redirect(url_for('activate_license_page'))(success, message) = None(license_key, 'web_activation')if request.is_json:
jsonify({
'success': success,
'message': message })if None:
flash(message, 'success')redirect(url_for('index'))None(message, 'danger')redirect(url_for('activate_license_page')))()
login = (lambda : if current_user.is_authenticated:
redirect(url_for('dashboard'))if None.method == 'POST':
username_or_email = request.form.get('username')password = request.form.get('password')remember = request.form.get('remember') == 'on'user = User.get_by_username(username_or_email)if not user:
user = User.get_by_email(username_or_email)if user and check_password_hash(user.password_hash, password):
if user.two_factor_enabled:
session['2fa_user_id'] = user.idredirect(url_for('two_factor'))None(user, remember = remember)now = datetime.now().isoformat()try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET last_login = ?, last_active = ? WHERE id = ?', (now, now, user.id))conn.commit()with None:
if not :
passNone(None, None)log_activity(user.id, 'login', 'auth', None, {
'ip': request.remote_addr })create_notification(user.id, 'info', 'New Login', f'''New login from {request.remote_addr}''', expires_in = 86400)flash(f'''Welcome back, {user.username}!''', 'success')next_page = request.args.get('next')if next_page:
redirect(next_page)get_db()(url_for('dashboard'))None('Invalid username/email or password', 'danger')log_activity(None, 'login_failed', 'auth', None, {
'username_or_email': username_or_email,
'ip': request.remote_addr })render_template('login.html', panel_name = get_setting('site_name', 'SVM PANEL'))try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET last_login = ?, last_active = ? WHERE id = ?', (now, now, user.id))conn.commit()with None:
if not :
passexcept:
passcontinue)()
two_factor = (lambda : if '2fa_user_id' not in session:
redirect(url_for('login'))if None.method == 'POST':
code = request.form.get('code')user_id = session.pop('2fa_user_id', None)user = User.get(user_id)if user:
login_user(user)now = datetime.now().isoformat()try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET last_login = ?, last_active = ? WHERE id = ?', (now, now, user.id))conn.commit()with None:
if not :
passNone(None, None)flash(f'''Welcome back, {user.username}!''', 'success')redirect(url_for('dashboard'))None('Invalid 2FA code', 'danger')render_template('2fa.html', panel_name = get_setting('site_name', 'SVM PANEL'))try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET last_login = ?, last_active = ? WHERE id = ?', (now, now, user.id))conn.commit()with None:
if not :
passexcept:
passcontinue)()
register = (lambda : if current_user.is_authenticated:
redirect(url_for('dashboard'))registration_enabled = None('registration_enabled', '1')if registration_enabled != '1':
flash('Registration is currently disabled', 'warning')redirect(url_for('login'))if None.method == 'POST':
username = request.form.get('username')email = request.form.get('email')password = request.form.get('password')confirm_password = request.form.get('confirm_password')terms = request.form.get('terms') == 'on'if not terms:
flash('You must accept the terms of service', 'danger')render_template('register.html', panel_name = get_setting('site_name', 'SVM PANEL'))if None != confirm_password:
flash('Passwords do not match', 'danger')render_template('register.html', panel_name = get_setting('site_name', 'SVM PANEL'))if None(password) < 8:
flash('Password must be at least 8 characters', 'danger')render_template('register.html', panel_name = get_setting('site_name', 'SVM PANEL'))if None.get_by_username(username):
flash('Username already taken', 'danger')render_template('register.html', panel_name = get_setting('site_name', 'SVM PANEL'))if None.get_by_email(email):
flash('Email already registered', 'danger')render_template('register.html', panel_name = get_setting('site_name', 'SVM PANEL'))password_hash = None(password)api_key = generate_api_key()now = datetime.now().isoformat()try:
conn = get_db()cur = conn.cursor()cur.execute('INSERT INTO users \n                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, api_key, preferences)\n                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', (username, email, password_hash, 0, 0, now, now, api_key, '{}'))user_id = cur.lastrowiddefault_quota = int(get_setting('default_port_quota', '5'))cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)', (user_id, default_quota, 0, now))conn.commit()with None:
if not :
passNone(None, None)log_activity(user_id, 'register', 'auth', None, {
'username': username,
'email': email })create_notification(user_id, 'success', 'Welcome!', f'''Welcome to {get_setting('site_name', 'SVM PANEL')}! Your account has been created.''')flash('Registration successful! Please log in.', 'success')redirect(url_for('login'))None('register.html', panel_name = get_setting('site_name', 'SVM PANEL'))try:
conn = get_db()cur = conn.cursor()cur.execute('INSERT INTO users \n                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, api_key, preferences)\n                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', (username, email, password_hash, 0, 0, now, now, api_key, '{}'))user_id = cur.lastrowiddefault_quota = int(get_setting('default_port_quota', '5'))cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)', (user_id, default_quota, 0, now))conn.commit()with None:
if not :
passexcept:
passcontinue)()
discord_login = (lambda : if not get_setting('discord_auth_enabled', '0') == '1':
flash('Discord authentication is not enabled', 'danger')redirect(url_for('login'))client_id = None('discord_client_id', '')redirect_uri = get_setting('discord_redirect_uri', '')if not client_id or redirect_uri:
flash('Discord authentication is not configured', 'danger')redirect(url_for('login'))state = None.token_urlsafe(32)session['discord_oauth_state'] = statesession['discord_oauth_action'] = 'login'params = {
'client_id': client_id,
'redirect_uri': redirect_uri,
'response_type': 'code',
'scope': 'identify email',
'state': state }oauth_url = f'''https://discord.com/api/oauth2/authorize?{urlencode(params)}'''redirect(oauth_url))()
discord_register = (lambda : if not get_setting('discord_auth_enabled', '0') == '1':
flash('Discord authentication is not enabled', 'danger')redirect(url_for('register'))if not None('registration_enabled', '1') == '1':
flash('Registration is currently disabled', 'danger')redirect(url_for('login'))client_id = None('discord_client_id', '')redirect_uri = get_setting('discord_redirect_uri', '')if not client_id or redirect_uri:
flash('Discord authentication is not configured', 'danger')redirect(url_for('register'))state = None.token_urlsafe(32)session['discord_oauth_state'] = statesession['discord_oauth_action'] = 'register'params = {
'client_id': client_id,
'redirect_uri': redirect_uri,
'response_type': 'code',
'scope': 'identify email',
'state': state }oauth_url = f'''https://discord.com/api/oauth2/authorize?{urlencode(params)}'''redirect(oauth_url))()
discord_callback = (lambda : state = request.args.get('state')if state or state != session.get('discord_oauth_state'):
flash('Invalid OAuth state', 'danger')redirect(url_for('login'))code = None.args.get('code')error = request.args.get('error')if error:
flash(f'''Discord authorization failed: {error}''', 'danger')redirect(url_for('login'))if not None:
flash('No authorization code received', 'danger')redirect(url_for('login'))client_id = None('discord_client_id', '')client_secret = get_setting('discord_client_secret', '')redirect_uri = get_setting('discord_redirect_uri', '')token_data = {
'client_id': client_id,
'client_secret': client_secret,
'grant_type': 'authorization_code',
'code': code,
'redirect_uri': redirect_uri }headers = {
'Content-Type': 'application/x-www-form-urlencoded' }try:
token_response = requests.post('https://discord.com/api/oauth2/token', data = token_data, headers = headers, timeout = 10)token_response.raise_for_status()token_json = token_response.json()access_token = token_json['access_token']except Exception:
logger.error(f'''Discord token exchange error: {e}''')flash('Failed to authenticate with Discord', 'danger')try:
user_response = requests.get('https://discord.com/api/users/@me', headers = {
'Authorization': f'''Bearer {access_token}''' }, timeout = 10)user_response.raise_for_status()discord_user = user_response.json()except Exception:
e = Nonelogger.error(f'''Discord user fetch error: {e}''')flash('Failed to fetch user information from Discord', 'danger')discord_id = discord_user['id']discord_username = f'''{discord_user['username']}#{discord_user['discriminator']}''' if discord_user.get('discriminator') and discord_user.get('discriminator') != '0' else discord_user['username']discord_email = discord_user.get('email')discord_avatar = discord_user.get('avatar')action = session.get('discord_oauth_action', 'login')session.pop('discord_oauth_state', None)session.pop('discord_oauth_action', None)try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE discord_id = ?', (discord_id,))existing_user = cur.fetchone()if action == 'login':
if existing_user:
user = User(dict(existing_user))login_user(user, remember = True)profile_picture = Noneif discord_avatar:
profile_picture = f'''https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png'''cur.execute('UPDATE users SET last_login = ?, last_active = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ? WHERE id = ?', (datetime.now().isoformat(), datetime.now().isoformat(), discord_username, discord_avatar, discord_email, profile_picture, user.id))conn.commit()log_activity(user.id, 'login_discord', 'auth', str(user.id))flash(f'''Welcome back, {user.username}!''', 'success')None(None, None)if None('discord_auto_register', '0') == '1':
None(None, None)None('No account found with this Discord account. Please register first.', 'warning')None(None, None)with None:
if not :
passif get_db() == 'register':
if existing_user:
flash('This Discord account is already registered. Please log in instead.', 'warning')None(None, None)None(None, None)if None == 'link':
if not current_user.is_authenticated:
flash('You must be logged in to link Discord', 'danger')None(None, None)if None and existing_user['id'] != current_user.id:
flash('This Discord account is already linked to another user', 'danger')None(None, None)if discord_avatar:
f'''https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png''' = Nonecur.execute('UPDATE users \n                SET discord_id = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ?\n                WHERE id = ?', (discord_id, discord_username, discord_avatar, discord_email, profile_picture, current_user.id))conn.commit()flash('Discord account linked successfully!', 'success')log_activity(current_user.id, 'link_discord', 'auth', str(current_user.id))None(None, None)None(None, None)flash('An error occurred during authentication', 'danger')redirect(url_for('login'))try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM users WHERE discord_id = ?', (discord_id,))existing_user = cur.fetchone()if action == 'login':
if existing_user:
user = User(dict(existing_user))login_user(user, remember = True)profile_picture = Noneif discord_avatar:
profile_picture = f'''https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png'''cur.execute('UPDATE users SET last_login = ?, last_active = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ? WHERE id = ?', (datetime.now().isoformat(), datetime.now().isoformat(), discord_username, discord_avatar, discord_email, profile_picture, user.id))conn.commit()log_activity(user.id, 'login_discord', 'auth', str(user.id))flash(f'''Welcome back, {user.username}!''', 'success')None(None, None)if None('discord_auto_register', '0') == '1':
None(None, None)None('No account found with this Discord account. Please register first.', 'warning')None(None, None)with None:
if not :
passexcept:
passcontinue)()

def discord_auto_register(discord_id, discord_username, discord_email, discord_avatar):
    '''Auto-register a new user from Discord'''
    
    try:
        pass
    except Exception:
        logger.error(f'''Discord auto-register error: {e}''')
        flash('Failed to create account. Please try again.', 'danger')

    
    try:
        conn = None
        cur = conn.cursor()
        base_username = discord_username.split('#')[0].lower()
        base_username = re.sub('[^a-z0-9_]', '', base_username)
        username = base_username
        counter = 1
        cur.execute('SELECT id FROM users WHERE username = ?', (username,))
        if not cur.fetchone():
            pass
        else:
            username = f'''{base_username}{counter}'''
            counter += 1
        email = discord_email if discord_email else f'''{username}@discord.local'''
        counter = 1
        original_email = email
        cur.execute('SELECT id FROM users WHERE email = ?', (email,))
        if not cur.fetchone():
            pass
        else:
            email = f'''{username}{counter}@discord.local'''
            counter += 1
        profile_picture = None
        if discord_avatar:
            profile_picture = f'''https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png'''
        random_password = secrets.token_urlsafe(32)
        password_hash = generate_password_hash(random_password)
        api_key = generate_api_key()
        now = datetime.now().isoformat()
        cur.execute('INSERT INTO users \n                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, last_active, api_key, preferences,\n                 discord_id, discord_username, discord_avatar, discord_email, profile_picture)\n                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (username, email, password_hash, 0, 0, now, now, now, api_key, '{}', discord_id, discord_username, discord_avatar, discord_email, profile_picture))
        user_id = cur.lastrowid
        default_quota = int(get_setting('default_port_quota', '5'))
        cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)', (user_id, default_quota, 0, now))
        conn.commit()
        cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user_row = cur.fetchone()
        user = User(dict(user_row))
        login_user(user, remember = True)
        log_activity(user.id, 'register_discord', 'auth', str(user.id))
        create_notification(user.id, 'success', 'Welcome!', f'''Welcome to {get_setting('site_name', 'Svm Panel')}, {username}! Your account has been created.''')
        flash(f'''Welcome to {get_setting('site_name', 'Svm Panel')}, {username}! Your account has been created.''', 'success')
    with None:
        if not :
            pass

    None(None, None)
    return 
    
    try:
        conn = None
        cur = conn.cursor()
        base_username = discord_username.split('#')[0].lower()
        base_username = re.sub('[^a-z0-9_]', '', base_username)
        username = base_username
        counter = 1
        cur.execute('SELECT id FROM users WHERE username = ?', (username,))
        if not cur.fetchone():
            pass
        else:
            username = f'''{base_username}{counter}'''
            counter += 1
        email = discord_email if discord_email else f'''{username}@discord.local'''
        counter = 1
        original_email = email
        cur.execute('SELECT id FROM users WHERE email = ?', (email,))
        if not cur.fetchone():
            pass
        else:
            email = f'''{username}{counter}@discord.local'''
            counter += 1
        profile_picture = None
        if discord_avatar:
            profile_picture = f'''https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png'''
        random_password = secrets.token_urlsafe(32)
        password_hash = generate_password_hash(random_password)
        api_key = generate_api_key()
        now = datetime.now().isoformat()
        cur.execute('INSERT INTO users \n                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, last_active, api_key, preferences,\n                 discord_id, discord_username, discord_avatar, discord_email, profile_picture)\n                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (username, email, password_hash, 0, 0, now, now, now, api_key, '{}', discord_id, discord_username, discord_avatar, discord_email, profile_picture))
        user_id = cur.lastrowid
        default_quota = int(get_setting('default_port_quota', '5'))
        cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)', (user_id, default_quota, 0, now))
        conn.commit()
        cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user_row = cur.fetchone()
        user = User(dict(user_row))
        login_user(user, remember = True)
        log_activity(user.id, 'register_discord', 'auth', str(user.id))
        create_notification(user.id, 'success', 'Welcome!', f'''Welcome to {get_setting('site_name', 'Svm Panel')}, {username}! Your account has been created.''')
        flash(f'''Welcome to {get_setting('site_name', 'Svm Panel')}, {username}! Your account has been created.''', 'success')
    with None:
        if not :
            pass

    except:
        pass

discord_link = (lambda : if not get_setting('discord_auth_enabled', '0') == '1':
flash('Discord authentication is not enabled', 'danger')redirect(url_for('profile'))client_id = None('discord_client_id', '')redirect_uri = get_setting('discord_redirect_uri', '')if not client_id or redirect_uri:
flash('Discord authentication is not configured', 'danger')redirect(url_for('profile'))state = None.token_urlsafe(32)session['discord_oauth_state'] = statesession['discord_oauth_action'] = 'link'params = {
'client_id': client_id,
'redirect_uri': redirect_uri,
'response_type': 'code',
'scope': 'identify email',
'state': state }oauth_url = f'''https://discord.com/api/oauth2/authorize?{urlencode(params)}'''redirect(oauth_url))()()
discord_link_callback = (lambda : state = request.args.get('state')if state or state != session.get('discord_oauth_state'):
flash('Invalid OAuth state', 'danger')redirect(url_for('profile'))code = None.args.get('code')if not code:
flash('No authorization code received', 'danger')redirect(url_for('profile'))client_id = None('discord_client_id', '')client_secret = get_setting('discord_client_secret', '')redirect_uri = get_setting('discord_redirect_uri', '').replace('/callback', '/link-callback')token_data = {
'client_id': client_id,
'client_secret': client_secret,
'grant_type': 'authorization_code',
'code': code,
'redirect_uri': redirect_uri }headers = {
'Content-Type': 'application/x-www-form-urlencoded' }try:
token_response = requests.post('https://discord.com/api/oauth2/token', data = token_data, headers = headers, timeout = 10)token_response.raise_for_status()token_json = token_response.json()access_token = token_json['access_token']user_response = requests.get('https://discord.com/api/users/@me', headers = {
'Authorization': f'''Bearer {access_token}''' }, timeout = 10)user_response.raise_for_status()discord_user = user_response.json()discord_id = discord_user['id']discord_username = f'''{discord_user['username']}#{discord_user['discriminator']}''' if discord_user.get('discriminator') and discord_user.get('discriminator') != '0' else discord_user['username']discord_email = discord_user.get('email')discord_avatar = discord_user.get('avatar')session.pop('discord_oauth_state', None)session.pop('discord_oauth_action', None)except Exception:
e = Nonelogger.error(f'''Discord link error: {e}''')flash('Failed to link Discord account', 'danger')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT id, username FROM users WHERE discord_id = ? AND id != ?', (discord_id, current_user.id))other_user = cur.fetchone()if other_user:
flash(f'''This Discord account is already linked to another user ({other_user[1]})''', 'danger')None(None, None)with None:
if not :
passif discord_avatar:
f'''https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png''' = Nonecur.execute('UPDATE users \n                SET discord_id = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ?\n                WHERE id = ?', (discord_id, discord_username, discord_avatar, discord_email, profile_picture, current_user.id))conn.commit()None(None, None)flash('Discord account linked successfully!', 'success')log_activity(current_user.id, 'link_discord', 'auth', str(current_user.id))redirect(url_for('profile'))try:
conn = Nonecur = conn.cursor()cur.execute('SELECT id, username FROM users WHERE discord_id = ? AND id != ?', (discord_id, current_user.id))other_user = cur.fetchone()if other_user:
flash(f'''This Discord account is already linked to another user ({other_user[1]})''', 'danger')None(None, None)with None:
if not :
passexcept:
passcontinue)()()
discord_unlink = (lambda : try:
passexcept Exception:
e = Nonelogger.error(f'''Discord unlink error: {e}''')flash('Failed to unlink Discord account', 'danger')try:
conn = Nonecur = conn.cursor()cur.execute('UPDATE users \n                SET discord_id = NULL, discord_username = NULL, discord_avatar = NULL, discord_email = NULL\n                WHERE id = ?', (current_user.id,))conn.commit()with None:
if not :
passNone(None, None)flash('Discord account unlinked successfully', 'success')log_activity(current_user.id, 'unlink_discord', 'auth', str(current_user.id))redirect(url_for('profile'))try:
conn = Nonecur = conn.cursor()cur.execute('UPDATE users \n                SET discord_id = NULL, discord_username = NULL, discord_avatar = NULL, discord_email = NULL\n                WHERE id = ?', (current_user.id,))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
logout = (lambda : log_activity(current_user.id, 'logout', 'auth')logout_user()flash('You have been logged out', 'info')redirect(url_for('index')))()()
forgot_password = (lambda : if request.method == 'POST':
email = request.form.get('email')flash('If the email exists, a reset link has been sent.', 'info')redirect(url_for('login'))None('forgot_password.html', panel_name = get_setting('site_name', 'SVM PANEL')))()
reset_password = (lambda token: if request.method == 'POST':
password = request.form.get('password')confirm_password = request.form.get('confirm_password')if password != confirm_password:
flash('Passwords do not match', 'danger')render_template('reset_password.html', token = token)None('Password reset successful. Please log in.', 'success')redirect(url_for('login'))None('reset_password.html', token = token, panel_name = get_setting('site_name', 'SVM PANEL')))()
notifications = (lambda : page = int(request.args.get('page', 1))per_page = 20offset = (page - 1) * per_pagetry:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM notifications \n                      WHERE user_id = ? AND (expires_at IS NULL OR expires_at > ?)\n                      ORDER BY created_at DESC LIMIT ? OFFSET ?', (current_user.id, datetime.now().isoformat(), per_page, offset))with None:
if not :
passfor None in :
passget_db(), [], notifications = Nonerow = Nonefor notif in notifications:
if not notif['data']:
continuetry:
notif['data'] = json.loads(notif['data'])except:
{ } = row,cur.execute('SELECT COUNT(*) FROM notifications \n                      WHERE user_id = ? AND (expires_at IS NULL OR expires_at > ?)', (current_user.id, datetime.now().isoformat()))total = cur.fetchone()[0]None(None, None)render_template('notifications.html', panel_name = get_setting('site_name', 'SVM PANEL'), notifications = notifications, page = page, total_pages = (total + per_page - 1) // per_page)try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM notifications \n                      WHERE user_id = ? AND (expires_at IS NULL OR expires_at > ?)\n                      ORDER BY created_at DESC LIMIT ? OFFSET ?', (current_user.id, datetime.now().isoformat(), per_page, offset))with None:
if not :
passexcept:
passrow,None, None, Nonecontinue)()()
unread_notifications = (lambda : notifications = get_user_notifications(current_user.id, unread_only = True, limit = 10)count = get_unread_notifications_count(current_user.id)jsonify({
'success': True,
'count': count,
'notifications': notifications }))()()
mark_notification_read_route = (lambda notification_id: success = mark_notification_read(notification_id, current_user.id)jsonify({
'success': success }))()()
mark_all_notifications_read_route = (lambda : count = mark_all_notifications_read(current_user.id)jsonify({
'success': True,
'count': count }))()()
clear_all_notifications = (lambda : try:
conn = get_db()cur = conn.cursor()cur.execute('DELETE FROM notifications WHERE user_id = ?', (current_user.id,))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True })try:
conn = get_db()cur = conn.cursor()cur.execute('DELETE FROM notifications WHERE user_id = ?', (current_user.id,))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
delete_notification_route = (lambda notification_id: try:
conn = get_db()cur = conn.cursor()cur.execute('DELETE FROM notifications WHERE id = ? AND user_id = ?', (notification_id, current_user.id))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True })try:
conn = get_db()cur = conn.cursor()cur.execute('DELETE FROM notifications WHERE id = ? AND user_id = ?', (notification_id, current_user.id))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
os_icons = (lambda : try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM os_icons ORDER BY os_name')with None:
if not :
passfor None in :
passget_db(), [], icons = Nonerow = NoneNone(None, None)render_template('admin/os_icons.html', panel_name = get_setting('site_name', 'SVM PANEL'), icons = icons, os_options = OS_OPTIONS)try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT * FROM os_icons ORDER BY os_name')with None:
if not :
passexcept:
passNone, None, Nonecontinue)()()()
upload_os_icon = (lambda : os_name = request.form.get('os_name')if 'icon' not in request.files:
(jsonify({
'success': False,
'error': 'No file uploaded' }), 400)file = None.files['icon']if file.filename == '':
(jsonify({
'success': False,
'error': 'No file selected' }), 400)if not None:
(jsonify({
'success': False,
'error': 'OS name required' }), 400)if not None(file.filename):
(jsonify({
'success': False,
'error': 'Invalid file type' }), 400)None.seek(0, os.SEEK_END)size = file.tell()file.seek(0)if size > app.config['MAX_IMAGE_SIZE']:
(jsonify({
'success': False,
'error': 'File too large (max 5MB)' }), 400)filename = None(f'''os_{os_name}_{int(time.time())}.{file.filename.rsplit('.', 1)[1].lower()}''')filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'os_icons', filename)os.makedirs(os.path.dirname(filepath), exist_ok = True)file.save(filepath)if PIL_AVAILABLE and Image:
try:
img = Image.open(filepath)img.thumbnail((64, 64), Image.Resampling.LANCZOS)img.save(filepath, optimize = True, quality = 85)icon_path = f'''/static/uploads/os_icons/{filename}'''try:
conn = get_db()cur = conn.cursor()cur.execute('INSERT OR REPLACE INTO os_icons (os_name, icon_path, uploaded_at, uploaded_by)\n                      VALUES (?, ?, ?, ?)', (os_name, icon_path, datetime.now().isoformat(), current_user.id))conn.commit()with None:
if not :
passNone(None, None)log_activity(current_user.id, 'upload_os_icon', 'os_icon', None, {
'os_name': os_name })jsonify({
'success': True,
'icon_path': icon_path })if Exception:
e = Nonelogger.error(f'''Failed to optimize image: {e}''')e = Nonedel econtinuee = Nonedel etry:
conn = get_db()cur = conn.cursor()cur.execute('INSERT OR REPLACE INTO os_icons (os_name, icon_path, uploaded_at, uploaded_by)\n                      VALUES (?, ?, ?, ?)', (os_name, icon_path, datetime.now().isoformat(), current_user.id))conn.commit()with None:
if not :
passexcept:
passcontinue)()()()
delete_os_icon = (lambda os_name: try:
passexcept Exception:
e = Nonelogger.error(f'''Error deleting OS icon: {e}''')try:
conn = Nonecur = conn.cursor()cur.execute('SELECT icon_path FROM os_icons WHERE os_name = ?', (os_name,))row = cur.fetchone()if row:
icon_path = row[0]cur.execute('DELETE FROM os_icons WHERE os_name = ?', (os_name,))conn.commit()try:
if icon_path and icon_path.startswith('/static/uploads/'):
file_path = icon_path.replace('/static/', 'static/')if os.path.exists(file_path):
os.remove(file_path)logger.info(f'''Deleted icon file: {file_path}''')log_activity(current_user.id, 'delete_os_icon', 'os_icon', None, {
'os_name': os_name })None(None, None)with None:
if not :
passNone(None, None)if Exception:
logger.warning(f'''Failed to delete icon file: {e}''')None = None, (None({
'success': False,
'error': 'Icon not found' }), 404), edel econtinuee = Nonedel etry:
conn = Nonecur = conn.cursor()cur.execute('SELECT icon_path FROM os_icons WHERE os_name = ?', (os_name,))row = cur.fetchone()if row:
icon_path = row[0]cur.execute('DELETE FROM os_icons WHERE os_name = ?', (os_name,))conn.commit()try:
if icon_path and icon_path.startswith('/static/uploads/'):
file_path = icon_path.replace('/static/', 'static/')if os.path.exists(file_path):
os.remove(file_path)logger.info(f'''Deleted icon file: {file_path}''')log_activity(current_user.id, 'delete_os_icon', 'os_icon', None, {
'os_name': os_name })None(None, None)with None:
if not :
passexcept:
pass)()()()
get_os_icon = (lambda os_name: try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT icon_path FROM os_icons WHERE os_name = ?', (os_name,))row = cur.fetchone()if row:
None(None, None)with None:
if not :
passNone(None, None)jsonify({
'success': True,
'icon_path': '/static/img/os/default.png' })try:
conn = get_db()cur = conn.cursor()cur.execute('SELECT icon_path FROM os_icons WHERE os_name = ?', (os_name,))row = cur.fetchone()if row:
None(None, None)with None:
if not :
passexcept:
passcontinue)()
profile = (lambda : if request.method == 'POST':
username = request.form.get('username')email = request.form.get('email')current_password = request.form.get('current_password')new_password = request.form.get('new_password')confirm_password = request.form.get('confirm_password')theme = request.form.get('theme')language = request.form.get('language')updates = { }if any([
username != current_user.username,
email != current_user.email,
new_password]):
if not current_password or check_password_hash(current_user.password_hash, current_password):
flash('Current password is incorrect', 'danger')redirect(url_for('profile'))if None and username != current_user.username:
if User.get_by_username(username):
flash('Username already taken', 'danger')else:
updates['username'] = usernameif email and email != current_user.email:
if User.get_by_email(email):
flash('Email already taken', 'danger')else:
updates['email'] = emailif new_password:
if new_password != confirm_password:
flash('New passwords do not match', 'danger')elif len(new_password) < 8:
flash('Password must be at least 8 characters', 'danger')else:
updates['password_hash'] = generate_password_hash(new_password)if theme:
updates['theme'] = themeif language:
updates['language'] = languageredirect(url_for('profile'))try:
conn = None()cur = conn.cursor()cur.execute('SELECT * FROM activity_logs WHERE user_id = ? \n                       ORDER BY created_at DESC LIMIT 50', (current_user.id,))with None:
if not :
passfor None in :
passNone(), [], activities = Nonerow = NoneNone(None, None)notifications = get_user_notifications(current_user.id, limit = 10)render_template('profile.html', panel_name = get_setting('site_name', 'SVM PANEL'), activities = activities, notifications = notifications)try:
conn = get_db()cur = conn.cursor()fields = (lambda .0: if None:
passfor k in .0:
if f'''{k} = ?''':
passf'''{k} = ?''')(updates())
        values = list(updates.values()) + [
            current_user.id]
        cur.execute(f'''UPDATE users SET {fields} WHERE id = ?''', values)
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass
    continue
    
    
    try:
        conn = None()
        cur = conn.cursor()
        cur.execute('SELECT * FROM activity_logs WHERE user_id = ? \n                       ORDER BY created_at DESC LIMIT 50', (current_user.id,))
    with None:
        if not :
            pass

    except:
        pass
    None, None, None
    continue
)()()
upload_profile_picture = (lambda : if 'picture' not in request.files:
(jsonify({
'success': False,
'error': 'No file uploaded' }), 400)file = None.files['picture']if file.filename == '':
(jsonify({
'success': False,
'error': 'No file selected' }), 400)if not None(file.filename):
(jsonify({
'success': False,
'error': 'Invalid file type' }), 400)None.seek(0, os.SEEK_END)size = file.tell()file.seek(0)if size > app.config['MAX_IMAGE_SIZE']:
(jsonify({
'success': False,
'error': 'File too large (max 5MB)' }), 400)filename = None(f'''user_{current_user.id}_{int(time.time())}.{file.filename.rsplit('.', 1)[1].lower()}''')filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'profiles', filename)os.makedirs(os.path.dirname(filepath), exist_ok = True)file.save(filepath)if PIL_AVAILABLE and Image:
try:
img = Image.open(filepath)img.thumbnail((256, 256), Image.Resampling.LANCZOS)img.save(filepath, optimize = True, quality = 85)if current_user.profile_picture:
old_path = current_user.profile_picture.lstrip('/')if os.path.exists(old_path):
try:
os.remove(old_path)except:
passtry:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET profile_picture = ? WHERE id = ?', (f'''/static/uploads/profiles/{filename}''', current_user.id))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True,
'path': f'''/static/uploads/profiles/{filename}''' })if Exception:
e = Nonelogger.error(f'''Failed to optimize image: {e}''')e = Nonedel econtinuee = Nonedel etry:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET profile_picture = ? WHERE id = ?', (f'''/static/uploads/profiles/{filename}''', current_user.id))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
delete_profile_picture = (lambda : if current_user.profile_picture:
old_path = current_user.profile_picture.lstrip('/')if os.path.exists(old_path):
try:
os.remove(old_path)try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET profile_picture = NULL WHERE id = ?', (current_user.id,))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True })continuetry:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET profile_picture = NULL WHERE id = ?', (current_user.id,))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
regenerate_api_key = (lambda : new_key = generate_api_key()try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET api_key = ? WHERE id = ?', (new_key, current_user.id))conn.commit()with None:
if not :
passNone(None, None)log_activity(current_user.id, 'regenerate_api_key', 'user', str(current_user.id))create_notification(current_user.id, 'warning', 'API Key Regenerated', 'Your API key has been regenerated.')jsonify({
'success': True,
'api_key': new_key })try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET api_key = ? WHERE id = ?', (new_key, current_user.id))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
update_preferences = (lambda : data = request.get_json()try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET preferences = ? WHERE id = ?', (json.dumps(data.get('preferences', { })), current_user.id))conn.commit()with None:
if not :
passNone(None, None)jsonify({
'success': True })try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET preferences = ? WHERE id = ?', (json.dumps(data.get('preferences', { })), current_user.id))conn.commit()with None:
if not :
passexcept:
passcontinue)()()
profile_picture = (lambda : if current_user.profile_picture and os.path.exists(current_user.profile_picture.lstrip('/')):
send_from_directory('static', current_user.profile_picture.replace('/static/', ''))None('static/img', 'default_avatar.png'))()()

def allowed_file(filename):
    if '.' in filename:
        '.' in filename
    return filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

dashboard = (lambda : try:
conn = get_db()cur = conn.cursor()cur.execute('UPDATE users SET last_active = ? WHERE id = ?', (datetime.now().isoformat(), current_user.id))conn.commit()with None:
if not :
passNone(None, None)vps_list = get_vps_for_user(current_user.id)for vps in vps_list:
if is_vps_suspended(vps):
vps['live_status'] = 'suspended'vps['live_cpu'] = 0vps['live_ram'] = {
'pct': 0 }continuetry:
stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))vps['live_status'] = stats['status']vps['live_cpu'] = stats['cpu']vps['live_ram'] = stats['ram']except:
vps['live_status'] = vps['status']vps['live_cpu'] = 0vps['live_ram'] = {
'pct': 0 }total_cpu = (lambda .0: if None:
passfor vps in .0:
if int(vps['cpu']):
passint(vps['cpu']))(vps_list())
    total_ram = (lambda .0: if None:
passfor vps in .0:
if int(str(vps['ram']).replace('GB', '').replace('MB', '')):
passint(str(vps['ram']).replace('GB', '').replace('MB', '')))(vps_list())
    total_disk = (lambda .0: if None:
passfor vps in .0:
if int(str(vps['storage']).replace('GB', '')):
passint(str(vps['storage']).replace('GB', '')))(vps_list())
    running_count = (lambda .0: if None:
passfor vps in .0:
if not vps.get('live_status') == 'running':
continueif is_vps_suspended(vps):
continueif 1:
pass1)(vps_list())
    suspended_count = (lambda .0: if None:
passfor vps in .0:
if not is_vps_suspended(vps):
continueif 1:
pass1)(vps_list())
    stopped_count = len(vps_list) - running_count - suspended_count
    notifications = get_user_notifications(current_user.id, unread_only = True, limit = 5)
    for vps in vps_list:
        if not vps.get('live_status') == 'running':
            continue
        if not vps.get('live_ram', { }).get('pct', 0) > 90:
            continue
        create_notification(current_user.id, 'warning', 'High RAM Usage', f'''VPS {vps['container_name']} is using high RAM ({vps['live_ram']['pct']:.1f}%)''')
    nodes = get_nodes()
    node_status = []
    for node in nodes[:3]:
        status = run_sync(get_node_status(node['id']))
        node_status.append({
            'id': node['id'],
            'name': node['name'],
            'status': status['status'],
            'online': status.get('online', False),
            'vps_count': get_current_vps_count(node['id']),
            'total_vps': node['total_vps'] })
    return render_template('dashboard.html', panel_name = get_setting('site_name', 'SVM PANEL'), site_description = get_setting('site_description', ''), header_icon = get_setting('header_icon', '/static/img/logo.png'), vps_list = vps_list, vps_count = len(vps_list), running_count = running_count, suspended_count = suspended_count, stopped_count = stopped_count, total_cpu = total_cpu, total_ram = total_ram, total_disk = total_disk, notifications = notifications, node_status = node_status, socketio_available = SOCKETIO_AVAILABLE)
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE users SET last_active = ? WHERE id = ?', (datetime.now().isoformat(), current_user.id))
        conn.commit()
    with None:
        if not :
            pass

    except:
        pass
    sum
    continue
)()()
vps_list = (lambda : vps_list = get_vps_for_user(current_user.id)for vps in vps_list:
vps['live_status'] = vps.get('status', 'unknown')vps['live_cpu'] = 0vps['live_ram'] = {
'used': 0,
'total': 0,
'pct': 0 }vps['live_disk'] = {
'use_percent': '0%' }if is_vps_suspended(vps):
vps['live_status'] = 'suspended'continuetry:
stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))vps['live_status'] = stats.get('status', 'unknown')vps['live_cpu'] = float(stats.get('cpu', 0))ram_data = stats.get('ram', {
'used': 0,
'total': 0,
'pct': 0 })if isinstance(ram_data, dict):
vps['live_ram'] = ram_dataelse:
vps['live_ram'] = {
'used': 0,
'total': 0,
'pct': 0 }disk_data = stats.get('disk', {
'use_percent': '0%' })if isinstance(disk_data, dict):
vps['live_disk'] = disk_dataelse:
vps['live_disk'] = {
'use_percent': '0%' }logger.debug(f'''VPS {vps['id']} stats: status={vps['live_status']}, cpu={vps['live_cpu']}, ram={vps['live_ram']}''')except Exception:
e = Nonelogger.warning(f'''Stats error for {vps.get('container_name')}: {e}''')vps['live_status'] = 'unknown'render_template('vps_list.html', panel_name = get_setting('site_name', 'SVM PANEL'), vps_list = vps_list, socketio_available = SOCKETIO_AVAILABLE))()()
vps_detail = (lambda vps_id: vps = get_vps_by_id(vps_id)if not vps:
flash('VPS not found', 'danger')redirect(url_for('vps_list'))if not None.get('shared_with', []):
None.get('shared_with', [])shared_with = []if not vps['user_id'] == current_user.id:
vps['user_id'] == current_user.idfor None in :
passif not str(current_user.id), shared_with, , [] in uid,:
str(current_user.id), shared_with, , [] in uid,current_user.is_admin = Noneif not allowed:
flash('VPS not found or access denied', 'danger')redirect(url_for('vps_list'))if not None(vps) and current_user.is_admin:
redirect(url_for('vps_suspended_page', vps_id = vps_id))node = None(vps['node_id'])try:
logger.info(f'''Fetching stats for container {vps['container_name']} on node {vps['node_id']}''')if not run_sync(get_container_stats(vps['container_name'], vps['node_id'])):
run_sync(get_container_stats(vps['container_name'], vps['node_id']))stats = { }logger.info(f'''Stats fetched for {vps['container_name']}: CPU={stats.get('cpu', 'N/A')}, Status={stats.get('status', 'N/A')}''')except Exception:
uid, e = None, None, Nonelogger.error(f'''Stats error for {vps['container_name']}: {e}''', exc_info = True)stats = {
'status': 'unknown',
'cpu': 0,
'ram': {
'used': 0,
'total': 0,
'pct': 0 },
'disk': {
'use_percent': '0%' },
'uptime': 'Unknown' }live_status = stats.get('status')if is_vps_suspended(vps):
live_status = 'suspended'vps['status'] = 'suspended'elif live_status in ('running', 'stopped') and live_status != vps.get('status'):
update_vps(vps_id, status = live_status)vps['status'] = live_statusprivate_ip = 'N/A'if live_status == 'running':
try:
private_ip = run_sync(get_container_private_ip(vps['container_name'], vps['node_id']))logger.info(f'''VPS {vps_id} ({vps['container_name']}) private IP: {private_ip}''')except Exception:
e = Nonelogger.error(f'''Error getting private IP for {vps['container_name']}: {e}''')private_ip = 'N/A'forwards = get_user_forwards(vps['user_id'])for None in :
if f['vps_container'] == vps['container_name']:
passcontinue, [], vps_forwards = None, forwardsf = Noneshared_users = []if shared_with:
logger.info(f'''VPS {vps_id} shared_with list: {shared_with}''')try:
conn = get_db()cur = conn.cursor()for uid in shared_with:
try:
uid_int = int(uid)cur.execute('\n                        SELECT id, username, email, profile_picture\n                        FROM users WHERE id=?\n                        ', (uid_int,))row = cur.fetchone()if row:
user_dict = dict(row)shared_users.append(user_dict)logger.info(f'''Added shared user: {user_dict['username']} (ID: {user_dict['id']})''')else:
logger.warning(f'''User ID {uid_int} not found in database''')continueNone(None, None)logger.info(f'''VPS {vps_id} total shared_users: {len(shared_users)}''')try:
conn = get_db()cur = conn.cursor()cur.execute('\n            SELECT * FROM backups\n            WHERE vps_id=?\n            ORDER BY created_at DESC\n            ', (vps_id,))with None:
if not :
passfor None in :
passget_db(), [], backups = Noner = NoneNone(None, None)try:
conn = get_db()cur = conn.cursor()cur.execute("\n            SELECT * FROM activity_logs\n            WHERE resource_type='vps'\n            AND resource_id=?\n            ORDER BY created_at DESC\n            LIMIT 20\n            ", (str(vps_id),))with None:
if not :
passfor None in :
passget_db(), [], activities = Noner = NoneNone(None, None)if not get_vps_display_ip(vps):
get_vps_display_ip(vps)display_ip = YOUR_SERVER_IPos_icon = 'default'for os_option in OS_OPTIONS:
if not os_option['value'] == vps['os_version']:
continueos_icon = os_option.get('icon', 'default')render_template('vps_detail.html', panel_name = get_setting('site_name', 'SVM PANEL'), vps = vps, node = node, stats = stats, forwards = vps_forwards, shared_users = shared_users, os_options = OS_OPTIONS, backups = backups, activities = activities, private_ip = private_ip, display_ip = display_ip, YOUR_SERVER_IP = YOUR_SERVER_IP, os_icon = os_icon, socketio_available = SOCKETIO_AVAILABLE)if Exception:
f, e = uid, e, None, None, None, Nonelogger.error(f'''Error loading shared user {uid}: {e}''')e = Nonedel econtinuee = Nonedel ewith None:
if not None:
passNone, None, Nonecontinuetry:
conn = get_db()cur = conn.cursor()cur.execute('\n            SELECT * FROM backups\n            WHERE vps_id=?\n            ORDER BY created_at DESC\n            ', (vps_id,))with None:
if not :
passexcept:
passNone, None, Nonecontinuetry:
conn = get_db()cur = conn.cursor()cur.execute("\n            SELECT * FROM activity_logs\n            WHERE resource_type='vps'\n            AND resource_id=?\n            ORDER BY created_at DESC\n            LIMIT 20\n            ", (str(vps_id),))with None:
if not :
passexcept:
passNone, None, Nonecontinue)()()

def get_sftp_connection(vps):
    '''Create SFTP connection to VPS'''
    import paramiko
    node = get_node(vps['node_id'])
    if not node:
        raise Exception('Node not found')
    urlparse = urlparse
    import urllib.parse
    parsed = urlparse(node['url'])
    node_host = node['url'].split('://')[1].split(':')[0] if not '://' in node['url'] or parsed.hostname else node['url'].split(':')[0]
    
    try:
        private_ip = run_sync(get_container_private_ip(vps['container_name'], vps['node_id']))
        if private_ip and private_ip != 'N/A':
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            try:
                ssh.connect(hostname = private_ip, port = 22, username = 'root', password = 'root', timeout = 5, allow_agent = False, look_for_keys = False)
                sftp = ssh.open_sftp()
                logger.info(f'''SFTP connected directly to {private_ip}:22''')

            return None
    except Exception:
        e = None
        logger.debug(f'''Could not get private IP: {e}''')

    
    try:
        conn = None()
        cur = conn.cursor()
        cur.execute('\n            SELECT host_port FROM port_forwards\n            WHERE vps_container = ? AND vps_port = 22\n        ', (vps['container_name'],))
        row = cur.fetchone()
        if row:
            ssh_port = row['host_port']
        else:
            logger.info(f'''Auto-creating SSH port forward for {vps['container_name']}''')
            
            try:
                host_port = run_sync(create_port_forward(user_id = vps['user_id'], container = vps['container_name'], vps_port = 22, node_id = vps['node_id'], protocol = 'tcp', description = 'SSH (auto-created for file manager)'))
                if not host_port:
                    raise Exception('No available ports for SSH forward')
                ssh_port = host_port
                logger.info(f'''Created SSH forward: {node_host}:{ssh_port} -> {vps['container_name']}:22''')
            except Exception:
                e = None
                raise Exception(f'''Could not create SSH port forward: {str(e)}''')
                e = None
                del e

            None(None, None)
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            try:
                ssh.connect(hostname = node_host, port = ssh_port, username = 'root', password = 'root', timeout = 10, allow_agent = False, look_for_keys = False)
                sftp = ssh.open_sftp()
                logger.info(f'''SFTP connected via port forward {node_host}:{ssh_port}''')
            except Exception:
                e = None
                ssh.close()
                raise Exception(f'''SFTP connection failed: {str(e)}''')
                e = None
                del e

            return None
    with None:
        if not :
            pass

    if Exception:
        e = None()
        logger.debug(f'''Direct IP connection failed: {e}, trying port forward''')
        ssh.close()
        e = None
        del e
        continue
        e = None
        del e
    
    try:
        conn = None()
        cur = conn.cursor()
        cur.execute('\n            SELECT host_port FROM port_forwards\n            WHERE vps_container = ? AND vps_port = 22\n        ', (vps['container_name'],))
        row = cur.fetchone()
        if row:
            ssh_port = row['host_port']
        else:
            logger.info(f'''Auto-creating SSH port forward for {vps['container_name']}''')
            
            try:
                host_port = run_sync(create_port_forward(user_id = vps['user_id'], container = vps['container_name'], vps_port = 22, node_id = vps['node_id'], protocol = 'tcp', description = 'SSH (auto-created for file manager)'))
                if not host_port:
                    raise Exception('No available ports for SSH forward')
                ssh_port = host_port
                logger.info(f'''Created SSH forward: {node_host}:{ssh_port} -> {vps['container_name']}:22''')
            except Exception:
                e = None
                raise Exception(f'''Could not create SSH port forward: {str(e)}''')
                e = None
                del e

            None(None, None)
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            try:
                ssh.connect(hostname = node_host, port = ssh_port, username = 'root', password = 'root', timeout = 10, allow_agent = False, look_for_keys = False)
                sftp = ssh.open_sftp()
                logger.info(f'''SFTP connected via port forward {node_host}:{ssh_port}''')
            except Exception:
                e = None
                ssh.close()
                raise Exception(f'''SFTP connection failed: {str(e)}''')
                e = None
                del e

            return None
    with None:
        if not :
            pass

    except:
        pass
    continue

vps_files = (lambda vps_id: vps = get_vps_by_id(vps_id)if not vps:
flash('VPS not found', 'danger')redirect(url_for('dashboard'))if not None['user_id'] != current_user.id and current_user.is_admin:
flash('Access denied', 'danger')redirect(url_for('dashboard'))if not None(vps) and current_user.is_admin:
flash('VPS is suspended. File manager access denied.', 'danger')redirect(url_for('vps_suspended_page', vps_id = vps_id))status = None(get_container_status(vps['container_name'], vps['node_id']))render_template('vps_files.html', panel_name = get_setting('site_name', 'SVM PANEL'), vps = vps, status = status))()()
vps_files_browse = (lambda vps_id: vps = get_vps_by_id(vps_id)if not (vps or vps['user_id'] != current_user.id) and current_user.is_admin:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)if not None(vps) and current_user.is_admin:
(jsonify({
'success': False,
'error': 'VPS is suspended' }), 403)data = None.get_json()path = data.get('path', '/root')if '..' in path:
(jsonify({
'success': False,
'error': 'Invalid path' }), 400)ssh = Nonesftp = Nonetry:
(ssh, sftp) = get_sftp_connection(vps)files = []for item in sftp.listdir_attr(path):
import statis_dir = stat.S_ISDIR(item.st_mode)is_link = stat.S_ISLNK(item.st_mode)if is_dir:
size = '-'else:
size_bytes = item.st_sizeif size_bytes < 1024:
size = f'''{size_bytes}B'''elif size_bytes < 1048576:
size = f'''{size_bytes / 1024:.1f}K'''elif size_bytes < 1073741824:
size = f'''{size_bytes / 1048576:.1f}M'''else:
size = f'''{size_bytes / 1073741824:.1f}G'''perms = stat.filemode(item.st_mode)datetime = datetimeimport datetimemodified = datetime.fromtimestamp(item.st_mtime).strftime('%Y-%m-%d %H:%M')files.append({
'name': item.filename,
'size': size,
'modified': modified,
'permissions': perms,
'owner': f'''{item.st_uid}:{item.st_gid}''',
'is_dir': is_dir,
'is_link': is_link })files.sort(key = (lambda x: (not x['is_dir'], x['name'].lower())))
    except Exception:
        e = None
        logger.error(f'''Error browsing files: {e}''')
        
        try:
            del e
        if sftp:
            except:
                if ssh:
                    ssh.close()

        if sftp:
            sftp.close()
        if ssh:
            ssh.close()
            return 
        None = 
        del e

    if sftp:
        sftp.close()
    if ssh:
        ssh.close()
        return None
    
    try:
        del e
    if sftp:
        except:
            if ssh:
                ssh.close()

)()()
vps_files_upload = (lambda vps_id: vps = get_vps_by_id(vps_id)if not (vps or vps['user_id'] != current_user.id) and current_user.is_admin:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)if not None(vps) and current_user.is_admin:
(jsonify({
'success': False,
'error': 'VPS is suspended' }), 403)if None not in request.files:
(jsonify({
'success': False,
'error': 'No file provided' }), 400)file = None.files['file']path = request.form.get('path', '/root')if file.filename == '':
(jsonify({
'success': False,
'error': 'No file selected' }), 400)if None in path or '..' in file.filename:
(jsonify({
'success': False,
'error': 'Invalid path' }), 400)ssh = Nonesftp = Nonetmp_path = Nonetry:
import tempfileexcept Exception:
e = Nonelogger.error(f'''Error uploading file: {e}''')try:
del eif tmp_path and os.path.exists(tmp_path):
except:
if sftp:
sftp.close()if tmp_path and os.path.exists(tmp_path):
os.unlink(tmp_path)if sftp:
sftp.close()if ssh:
ssh.close()None = del etry:
tmp = Nonefile.save(tmp.name)tmp_path = tmp.namewith None:
if not :
passNone(None, None)(ssh, sftp) = get_sftp_connection(vps)target_path = f'''{path.rstrip('/')}/{file.filename}'''sftp.put(tmp_path, target_path)log_activity(current_user.id, 'upload_file', 'vps', str(vps_id), {
'file': file.filename,
'path': path })if tmp_path and os.path.exists(tmp_path):
os.unlink(tmp_path)if sftp:
sftp.close()if ssh:
ssh.close()jsonify({
'success': True,
'message': f'''File {file.filename} uploaded successfully''' })try:
tmp = Nonefile.save(tmp.name)tmp_path = tmp.namewith None:
if not :
passexcept:
passcontinuetry:
del eif tmp_path and os.path.exists(tmp_path):
except:
if sftp:
sftp.close()if ssh:
ssh.close())()()
vps_files_download = (lambda vps_id: vps = get_vps_by_id(vps_id)if not (vps or vps['user_id'] != current_user.id) and current_user.is_admin:
(jsonify({
'success': False,
'error': 'Access denied' }), 403)if not None(vps) and current_user.is_admin:
(jsonify({
'success': False,
'error': 'VPS is suspended' }), 403)data = None.get_json()file_path = data.get('path')if file_path or '..' in file_path:
(jsonify({
'success': False,
'error': 'Invalid path' }), 400)ssh = Nonesftp = Nonetmp_path = Nonetry:
import tempfile(ssh, sftp) = get_sftp_connection(vps)tmp = tempfile.NamedTemporaryFile(delete = False)tmp.close()tmp_path = tmp.namesftp.get(file_path, tmp_path)filename = os.path.basename(file_path)log_activity(current_user.id, 'download_file', 'vps', str(vps_id), {
'file': file_path })except Exception:
e = Nonelogger.error(f'''Error downloading file: {e}''')if tmp_path and os.path.exists(tmp_path):
os.unlink(tmp_path)try:
del eif sftp:
except:
if ssh:
ssh.close()if sftp:
sftp.close()if ssh:
ssh.close()None = del eif sftp:
sftp.close()if ssh:
ssh.close()Nonetry:
del eif sftp:
except:
if ssh:
ssh.close())()()
vps_files_delete = (lambda vps_id: 
